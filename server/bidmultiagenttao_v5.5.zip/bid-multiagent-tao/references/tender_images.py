#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
图片打标 · 共享解析库（build_tender_docx.py 与 fill_tender_template.py 共用，需与二者同目录）

标书里的"打标"语法（md 正文或 docx 模板中均可写，独立成行/单独占一段效果最佳）：
  {{图:产品架构图}}              ← 图片ID：到素材库"图片索引"查文件与默认图注
  {{图:产品架构图|总体架构图}}   ← 竖线后自定义图注
  〔图:营业执照〕                ← 全角括号写法等价；冒号全/半角均可；前缀可写 图/图片/img/image
  ![图注](素材/图片/xx.png)      ← 标准 markdown 图片语法（直接给路径）同样支持

图片素材库（跨项目长期复用，打标只认"图片ID"，换项目/换图不改标书正文）：
  素材/图片/*.png|jpg|jpeg|gif|bmp|tif  +  素材/图片索引.md（或 图片索引.json）
  图片索引.md 是一张表：| 图片ID | 文件 | 默认图注 | 适用场景/关键词 |（文件路径相对索引文件所在目录）
  图片索引.json 形如 {"产品架构图": {"file": "图片/arch.png", "caption": "总体架构图"}} 或 {"ID": "file.png"}

没有索引也能用：图片ID 直接当文件名，在素材目录里找同名/近名文件。
找不到的图不报错：降级为〔需人工插入〕占位，结束时统一汇总提醒（与补料清单同一理念）。
"""
import os, re, json

IMG_EXTS = ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tif', '.tiff', '.emf', '.wmf')

# {{图:ID}} / {{图:ID|图注}} / 〔图:ID〕，前缀 图/图片/img/image，冒号与竖线全半角均可
MARKER_RE = re.compile(
    r'(?:\{\{|〔)\s*(?:图片?|img|image)\s*[:：]\s*([^|｜}〕\n]+?)\s*(?:[|｜]\s*([^}〕\n]+?)\s*)?(?:\}\}|〕)',
    re.IGNORECASE)
# 标准 markdown 图片：![图注](路径 "可选title")
MD_IMG_RE = re.compile(r'!\[([^\]\n]*)\]\(\s*<?([^)\s>]+)>?(?:\s+["\'][^)]*["\'])?\s*\)')


def has_image_marker(text):
    return bool(MARKER_RE.search(text) or MD_IMG_RE.search(text))


def split_image_markers(text):
    """把一行/一段文本切成 [('text', 文本), ('image', 引用, 图注或None), ...] 顺序保持"""
    segs, pos = [], 0
    hits = [(m.start(), m.end(), m.group(1).strip(), (m.group(2) or '').strip() or None)
            for m in MARKER_RE.finditer(text)]
    hits += [(m.start(), m.end(), m.group(2).strip(), (m.group(1) or '').strip() or None)
             for m in MD_IMG_RE.finditer(text)]
    for start, end, ref, cap in sorted(hits):
        if start < pos:  # 与前一命中重叠（理论上不会），跳过
            continue
        if start > pos: segs.append(('text', text[pos:start], None))
        segs.append(('image', ref, cap))
        pos = end
    if pos < len(text): segs.append(('text', text[pos:], None))
    return segs


class ImageLibrary:
    """图片素材库：定位素材目录 → 读图片索引 → 把打标引用解析成文件路径+默认图注"""

    def __init__(self, images_dir=None, fallback_dirs=None):
        self.search_dirs, seen = [], set()
        for d in ([images_dir] if images_dir else []) + list(fallback_dirs or []):
            if not d: continue
            d = os.path.abspath(d)
            for cand in (d, os.path.join(d, '素材'), os.path.join(d, '图片'),
                         os.path.join(d, '素材', '图片'), os.path.join(d, 'images')):
                if cand not in seen and os.path.isdir(cand):
                    seen.add(cand); self.search_dirs.append(cand)
        self.index = {}          # ID -> (abspath, caption)
        self.index_path = None
        self._load_index()
        self.inserted = []       # 成功插入的 (ref, path)
        self.missing = []        # 未命中的 ref
        self.fig_of = {}         # 已插入文件 abspath -> 图号（同图多次打标时，导出器用它改写为"见图N"引用）

    # ---- 索引 ----
    def _load_index(self):
        for d in self.search_dirs:
            for name in ('图片索引.md', '图片索引.json', 'image_index.md', 'image_index.json'):
                p = os.path.join(d, name)
                if os.path.isfile(p):
                    try:
                        (self._parse_json if p.endswith('.json') else self._parse_md)(p)
                        self.index_path = p
                        return
                    except Exception:
                        continue

    def _parse_json(self, path):
        base = os.path.dirname(path)
        data = json.load(open(path, encoding='utf-8'))
        for key, val in data.items():
            if isinstance(val, str): f, cap = val, None
            elif isinstance(val, dict): f, cap = val.get('file') or val.get('path'), val.get('caption') or val.get('图注')
            else: continue
            if f: self.index[str(key).strip()] = (os.path.normpath(os.path.join(base, f)), cap)

    def _parse_md(self, path):
        base = os.path.dirname(path)
        rows = []
        for ln in open(path, encoding='utf-8'):
            ln = ln.strip()
            if not ln.startswith('|'): continue
            if set(ln.replace('|', '').replace('-', '').replace(':', '').strip()) == set(): continue
            rows.append([c.strip() for c in ln.strip('|').split('|')])
        if not rows: return
        head = [h.lower() for h in rows[0]]
        def col(*keys, default=None):
            for i, h in enumerate(head):
                if any(k in h for k in keys): return i
            return default
        ci, cf = col('图片id', 'id', default=0), col('文件', '路径', 'file', default=1)
        cc = col('图注', '标题', 'caption', default=2)
        body = rows[1:] if any(k in ''.join(head) for k in ('id', '文件', '图注', 'file')) else rows
        for r in body:
            if len(r) <= max(ci, cf): continue
            rid, f = r[ci], r[cf]
            if not rid or not f or rid.startswith('（'): continue
            cap = r[cc] if cc is not None and len(r) > cc and r[cc] not in ('', '—', '-') else None
            self.index[rid] = (os.path.normpath(os.path.join(base, f)), cap)

    # ---- 解析 ----
    def resolve(self, ref):
        """打标引用 → (存在的图片绝对路径 | None, 默认图注 | None)"""
        ref = (ref or '').strip()
        if not ref: return None, None
        if ref in self.index:
            p, cap = self.index[ref]
            if os.path.isfile(p): return p, cap
        # 当作路径：相对各搜索目录找
        cands = [ref] if os.path.splitext(ref)[1].lower() in IMG_EXTS \
            else [ref + e for e in IMG_EXTS] + [ref]
        for d in [''] + self.search_dirs:
            for c in cands:
                p = os.path.join(d, c) if d else c
                if os.path.isfile(p) and os.path.splitext(p)[1].lower() in IMG_EXTS:
                    return os.path.abspath(p), None
        # 最后一搏：素材目录里唯一的"文件名包含ref"命中
        hit = []
        for d in self.search_dirs:
            for fn in sorted(os.listdir(d)):
                if os.path.splitext(fn)[1].lower() in IMG_EXTS and ref in os.path.splitext(fn)[0]:
                    hit.append(os.path.join(d, fn))
        if len(set(os.path.basename(h) for h in hit)) == 1 and hit:
            return os.path.abspath(hit[0]), None
        return None, None

    def report(self):
        lines = []
        if self.inserted: lines.append('图片：自动插入 %d 张' % len(self.inserted))
        if self.missing:
            lines.append('⚠️ %d 处图片打标未命中素材，已留〔需人工插入〕占位：%s'
                         % (len(self.missing), '、'.join(dict.fromkeys(self.missing))))
            if not self.index_path:
                lines.append('  （未找到 图片索引.md/json——可用 --images-dir 指定素材目录）')
        return lines


def natural_size_cm(path):
    """图片自然尺寸(cm)，按文件内 DPI 换算；失败返回 None"""
    try:
        from docx.image.image import Image
        im = Image.from_file(path)
        return im.width.cm, im.height.cm
    except Exception:
        return None


def fit_image(path, max_w_cm, max_h_cm):
    """等比缩放进 max_w×max_h 的框，不放大超过自然尺寸 → (w_cm, h_cm)；尺寸未知 → (max_w, None) 只锁宽"""
    nat = natural_size_cm(path)
    if not nat or nat[0] <= 0 or nat[1] <= 0:
        return max_w_cm, None
    w, h = nat
    scale = min(max_w_cm / w, max_h_cm / h, 1.0)
    return w * scale, h * scale
