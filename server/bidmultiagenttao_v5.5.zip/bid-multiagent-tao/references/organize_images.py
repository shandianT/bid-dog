#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
图片语义化改名 · 把素材库里的"哈希/随机文件名"改成"图片ID.扩展名"——打标痕迹落到文件名上，下次复用一眼看懂
用法：python3 organize_images.py <素材库目录> [--apply]
  默认试运行（只打印改名计划，不动任何文件）；加 --apply 才真正执行。

背景：入库员建好 图片索引.md 后，打标体系已经可用（标书只认"图片ID"，索引负责 ID→文件映射），
但素材文件夹里还是 7f6a4ddf….jpg 这类原始文件名，人眼看不出哪张是哪张。本脚本做三件事（全部确定性）：
1. 读 <素材库>/图片索引.md：取每行 图片ID → 文件；
2. 把文件改名为 <图片ID>.<原扩展名>（ID 里的非法字符替换为 -），如 资质-ISO9001.jpg；
3. 同步改写索引"文件"列，并把 旧名→新名 追加进 _重命名记录.md（可追溯，误改可按记录改回）。

安全性：
- 标书正文的 {{图:ID}} 打标、能力表"配图"列引用的都是**图片ID**，不引用文件名——改名不影响任何已打标内容；
- 已是语义名的跳过；目标名已存在的跳过并告警；索引里没登记的文件不动；
- 跑不了本脚本也不影响复用：图片索引.md 本身就是 ID↔文件 的"户口本"，文件名只是给人看的。
"""
import sys, os, re, argparse

BAD = re.compile(r'[\\/:*?"<>|\s]+')


def cols_of(ln):
    return [c.strip() for c in ln.strip().strip('|').split('|')]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('materials', help='素材库目录（含 图片索引.md）')
    ap.add_argument('--apply', action='store_true', help='真正执行改名（默认试运行只打印计划）')
    a = ap.parse_args()
    mat = os.path.abspath(a.materials)
    idx_path = None
    for d in (mat, os.path.join(mat, '图片'), os.path.join(mat, '素材')):
        p = os.path.join(d, '图片索引.md')
        if os.path.isfile(p):
            idx_path = p
            break
    if not idx_path:
        print('❌ 没找到 图片索引.md——先跑"标书04-图片入库"建索引，再来语义化改名。')
        sys.exit(2)
    base = os.path.dirname(idx_path)

    lines = open(idx_path, encoding='utf-8').read().splitlines()
    out, plans = [], []
    header, ci, cf = None, 0, 1
    for ln in lines:
        s = ln.strip()
        is_row = s.startswith('|')
        is_sep = is_row and set(s.replace('|', '').replace('-', '').replace(':', '').strip()) == set()
        if is_row and not is_sep and header is None:
            header = [h.lower() for h in cols_of(ln)]
            def col(*keys, default):
                for i, h in enumerate(header):
                    if any(k in h for k in keys):
                        return i
                return default
            ci = col('图片id', 'id', default=0)
            cf = col('文件', '路径', 'file', default=1)
            out.append(ln)
            continue
        if not is_row or is_sep or header is None:
            out.append(ln)
            continue
        cells = cols_of(ln)
        if len(cells) <= max(ci, cf):
            out.append(ln)
            continue
        rid, f = cells[ci], cells[cf]
        src = os.path.normpath(os.path.join(base, f))
        if not rid or not f or rid.startswith('（') or not os.path.isfile(src):
            out.append(ln)
            continue
        ext = os.path.splitext(src)[1].lower()
        safe = BAD.sub('-', rid).strip('-')
        rel_dir = os.path.dirname(f)
        tgt_rel = (rel_dir + '/' if rel_dir else '') + safe + ext
        tgt = os.path.normpath(os.path.join(base, tgt_rel))
        if src == tgt:
            out.append(ln)
            continue
        if os.path.exists(tgt):
            print('⚠️ 跳过 %s：目标名已存在 %s' % (f, tgt_rel))
            out.append(ln)
            continue
        plans.append((rid, f, tgt_rel.replace('\\', '/'), src, tgt))
        cells[cf] = tgt_rel.replace('\\', '/')
        out.append('| ' + ' | '.join(cells) + ' |')

    if not plans:
        print('没有需要改名的文件（都已语义化，或索引未命中任何现存文件）。')
        return
    for rid, old, new, _s, _t in plans:
        print('%s  %s  →  %s   （ID: %s）' % ('改名' if a.apply else '计划', old, new, rid))
    if not a.apply:
        print('\n以上为试运行（未动任何文件）。确认无误后加 --apply 执行：改文件名 + 同步索引 + 留 _重命名记录.md。')
        return

    for _rid, _old, _new, src, tgt in plans:
        os.rename(src, tgt)
    with open(idx_path, 'w', encoding='utf-8') as fo:
        fo.write('\n'.join(out) + '\n')
    logp = os.path.join(os.path.dirname(plans[0][4]), '_重命名记录.md')
    with open(logp, 'a', encoding='utf-8') as fo:
        for rid, old, new, _s, _t in plans:
            fo.write('- %s → %s （ID: %s）\n' % (old, new, rid))
    print('\n✅ 已改名 %d 张，索引"文件"列已同步，记录见 %s' % (len(plans), logp))
    print('标书 {{图:ID}} 打标与能力表"配图"列引用的都是图片ID——无需任何改动，下次投标直接复用整个素材目录。')


if __name__ == '__main__':
    main()
