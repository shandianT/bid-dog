#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
进度上报 · 各环节 Agent 调用本脚本把进度写进 progress.json —— 网页端轮询这个文件即可实时显示流程进度
用法：python3 progress_update.py --file <工作空间>/progress.json --stage "06撰写" --status running|done|error \
        [--unit "第3章"] [--total-units 6] [--note "一句话说明"]

- 阶段固定顺序内置（00预检…11出Word），未知阶段自动追加到末尾；
- 带 --unit 表示并行子任务（如各章撰写）：逐 unit 记状态；给了 --total-units 且全部 done 时阶段自动置 done；
- percent 按"已完成阶段/总阶段"计算（撰写阶段按 units 完成度折算）；
- 原子写入（临时文件+替换），并发调用安全；任何异常静默退出码 0——进度上报绝不影响主任务。
产品端最小闭环：app 端在工作空间起 `python3 -m http.server 8080`，网页打开 progress-monitor.html
（或产品自己的页面）轮询 http://<app>:8080/progress.json 即可。
"""
import sys, os, json, argparse, tempfile, datetime

STAGES = [("00预检", "体检素材"), ("04图片入库", "图片入库"), ("01组成规划", "读懂组成"),
          ("02格式提取", "提取格式"), ("03评分废标", "评分废标"), ("05拆解", "拆解分工"),
          ("06撰写", "分章撰写"), ("07应答偏离", "逐条应答"), ("08汇总净化", "汇总成册"),
          ("09配图复核", "配图复核"), ("10验证自检", "自查体检"), ("11出Word", "出Word门禁")]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--file', required=True)
    ap.add_argument('--stage', required=True)
    ap.add_argument('--status', required=True, choices=['running', 'done', 'error'])
    ap.add_argument('--unit', default=None)
    ap.add_argument('--total-units', type=int, default=None)
    ap.add_argument('--note', default=None)
    a = ap.parse_args()

    data = {"stages": [{"id": i, "name": n, "status": "pending", "units": {}, "note": ""} for i, n in STAGES]}
    if os.path.isfile(a.file):
        try:
            data = json.load(open(a.file, encoding='utf-8'))
        except Exception:
            pass
    by_id = {s.get("id"): s for s in data.get("stages", [])}
    st = by_id.get(a.stage)
    if st is None:
        st = {"id": a.stage, "name": a.stage, "status": "pending", "units": {}, "note": ""}
        data.setdefault("stages", []).append(st)
    if a.unit:
        st.setdefault("units", {})[a.unit] = a.status
        if a.total_units: st["total_units"] = a.total_units
        total = st.get("total_units") or len(st["units"])
        done = sum(1 for v in st["units"].values() if v == 'done')
        st["status"] = 'error' if 'error' in st["units"].values() else ('done' if done >= total else 'running')
    else:
        st["status"] = a.status
    if a.note: st["note"] = a.note

    stages = data.get("stages", [])
    score = 0.0
    for s in stages:
        if s.get("status") == 'done': score += 1
        elif s.get("units"):
            total = s.get("total_units") or len(s["units"]) or 1
            score += min(1.0, sum(1 for v in s["units"].values() if v == 'done') / total)
        elif s.get("status") == 'running': score += 0.3
    data["percent"] = int(100 * score / max(1, len(stages)))
    data["updated_at"] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    d = os.path.dirname(os.path.abspath(a.file)) or '.'
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix='.tmp')
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, a.file)
    print('进度已更新: %s → %s%s (%d%%)' % (a.stage, a.status, ' [%s]' % a.unit if a.unit else '', data["percent"]))


if __name__ == '__main__':
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        print('进度上报失败(不影响主任务): %s' % e)
        sys.exit(0)
