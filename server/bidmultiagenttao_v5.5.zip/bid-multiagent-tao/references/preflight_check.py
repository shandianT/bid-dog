#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
预检器 · 跑标书流程前的确定性体检(第0步必跑,弱模型也不会跑偏)
用法：python3 preflight_check.py --tender <招标文件> --out <输出目录> [--materials <素材库>] [--json]

干三件事(全部是确定性检查,不靠模型判断)：
1. 素材库定位：按候选顺序找真实存在的素材库目录,逐项清点里面有什么、缺什么——
   候选顺序：--materials 指定 > <招标文件同目录>/素材 > ./素材 > ./演示素材包 > <out>/素材
   ⚠️ 素材读不到的第一大原因就是路径没接上：调用 Workflow 时忘传 materialsDir,
   工作流会默认去 <out>/素材 找——素材放在别处就整条链路静默降级成占位版。
2. 招标文件体检：存在?非空?是可直接读的 md/txt,还是要先转换的 pdf/docx/zip/扫描件?
3. 环境体检：python-docx(出Word必需)、mermaid-cli/npx(流程图可选)是否可用。

输出：人读报告 + 一段可直接复制的 Workflow args(全部绝对路径)。--json 输出机器可读 JSON。
退出码：0=可以开跑(可能带警告)；2=招标文件不存在/为空,必须先解决。
"""
import sys, os, json, glob, shutil, argparse

RECOMMENDED = ['公司介绍.md', '产品资料.md', '产品能力表.md', '资质与案例.md', '应答要点.md']
IMG_EXTS = ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tif', '.tiff')
DIRECT_READ = ('.md', '.markdown', '.txt')
NEED_CONVERT = {'.pdf': 'PDF', '.docx': 'Word', '.doc': 'Word', '.zip': '压缩包', '.rar': '压缩包', '.7z': '压缩包'}


def find_materials(cli_dir, tender, out):
    cands = []
    if cli_dir: cands.append(('--materials 指定', cli_dir))
    if tender: cands.append(('招标文件同目录/素材', os.path.join(os.path.dirname(os.path.abspath(tender)), '素材')))
    cands.append(('当前目录/素材', os.path.join(os.getcwd(), '素材')))
    cands.append(('当前目录/演示素材包', os.path.join(os.getcwd(), '演示素材包')))
    if out: cands.append(('输出目录/素材', os.path.join(os.path.abspath(out), '素材')))
    for label, d in cands:
        if os.path.isdir(d):
            return label, os.path.abspath(d), [c[1] for c in cands]
    return None, None, [c[1] for c in cands]


def scan_materials(mat):
    found, missing = [], []
    for f in RECOMMENDED:
        (found if os.path.isfile(os.path.join(mat, f)) else missing).append(f)
    idx = os.path.join(mat, '图片索引.md')
    has_idx = os.path.isfile(idx)
    imgs = []
    for pat in ('图片/*', '*'):
        imgs = [p for p in glob.glob(os.path.join(mat, pat)) if p.lower().endswith(IMG_EXTS)]
        if imgs: break
    cap_note = None
    cap = os.path.join(mat, '产品能力表.md')
    if os.path.isfile(cap):
        head = open(cap, encoding='utf-8', errors='ignore').read(4000)
        rows = max(0, sum(1 for l in head.splitlines() if l.strip().startswith('|')) - 2)
        cap_note = '约%d行' % rows + ('，含"配图"列(逐条应答可自动配证明图)' if '配图' in head else '，无"配图"列(应答不会自动配图,可让入库员回填)')
    return found, missing, has_idx, len(imgs), cap_note


def check_tender(path):
    if not path or not os.path.isfile(path):
        return False, '❌ 招标文件不存在：%s —— 先确认路径(用绝对路径)。' % path
    if os.path.getsize(path) == 0:
        return False, '❌ 招标文件是空文件：%s' % path
    ext = os.path.splitext(path)[1].lower()
    if ext in DIRECT_READ:
        return True, '✅ %s 可直接读取(%.0f KB)' % (ext, os.path.getsize(path) / 1024)
    if ext in NEED_CONVERT:
        return True, ('⚠️ 招标文件是 %s：Agent 无法逐字精读,必须先转成 招标文件_解析版.md(正文+全部附件,'
                      '附件里往往藏着格式要求和响应模板),再把解析版路径传给流程。' % NEED_CONVERT[ext])
    return True, '⚠️ 未识别的扩展名 %s：请确认 Agent 能直接读取,否则先转 md。' % (ext or '(无)')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tender', required=True, help='招标文件路径')
    ap.add_argument('--out', required=True, help='输出目录(工作空间)')
    ap.add_argument('--materials', default=None, help='素材库目录(不传则按候选顺序自动找)')
    ap.add_argument('--skill-dir', default=None, help='skill 目录,默认取本脚本上级目录')
    ap.add_argument('--json', action='store_true', help='输出机器可读 JSON')
    a = ap.parse_args()

    skill_dir = os.path.abspath(a.skill_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    out = os.path.abspath(a.out)
    tender_ok, tender_note = check_tender(a.tender)
    tender = os.path.abspath(a.tender) if a.tender and os.path.isfile(a.tender) else a.tender

    label, mat, cands = find_materials(a.materials, tender if tender_ok else None, out)
    warnings = []
    if not tender_note.startswith('✅'): warnings.append(tender_note)

    if mat:
        found, missing, has_idx, n_img, cap_note = scan_materials(mat)
    else:
        found, missing, has_idx, n_img, cap_note = [], list(RECOMMENDED), False, 0, None
        warnings.append('❌ 没找到素材库目录(找过：%s)。没有素材也能跑,但偏离表只能出占位版、章节没有真实弹药——'
                        '内容会明显变薄。建议按 素材模板_投标方信息.md 建库后重跑,或用 --materials 指定真实位置。' % '；'.join(cands))
    if mat and '产品能力表.md' in missing:
        warnings.append('⚠️ 缺 产品能力表.md——它是逐条应答的第一判定依据,缺了偏离表质量会明显下降。')
    if mat and not has_idx and n_img:
        warnings.append('⚠️ 图片有 %d 张但没有 图片索引.md——自动配图不会生效。可召唤"角色⓪D 图片素材入库员"自动建索引。' % n_img)

    try:
        import docx  # noqa: F401
        docx_ok = True
    except ImportError:
        docx_ok = False
        warnings.append('⚠️ 未安装 python-docx——出 Word 阶段会失败。先 pip install python-docx；'
                        '装不上就交付 md + 导出命令给用户本机跑,禁止改用其他工具导出(格式会全丢)。')
    mermaid_ok = bool(shutil.which('mmdc') or shutil.which('npx'))
    if not mermaid_ok:
        warnings.append('ℹ️ 无 mermaid-cli/npx：流程图会降级为图注(不阻塞)。')

    result = {
        'tender_path': tender, 'tender_ok': tender_ok, 'tender_note': tender_note,
        'out_dir': out, 'skill_dir': skill_dir,
        'materials_dir': mat, 'materials_source': label,
        'materials_found': found, 'materials_missing': missing,
        'has_image_index': has_idx, 'image_count': n_img, 'capability_table': cap_note,
        'python_docx': docx_ok, 'mermaid': mermaid_ok, 'warnings': warnings,
    }
    if a.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if tender_ok else 2)

    print('=== 标书流程预检 ===')
    print('招标文件: %s' % tender_note)
    print('          %s' % tender)
    if mat:
        print('素材库  : ✅ %s → %s' % (label, mat))
        print('          已有: %s' % ('、'.join(found) if found else '(无推荐文件)'))
        if missing: print('          缺失: %s' % '、'.join(missing))
        if cap_note: print('          产品能力表: %s' % cap_note)
        print('          图片: %d 张，图片索引: %s' % (n_img, '✅ 有(自动配图可用)' if has_idx else '❌ 无'))
    else:
        print('素材库  : ❌ 未找到')
    print('依赖    : python-docx %s ｜ mermaid %s' % ('✅' if docx_ok else '❌', '✅' if mermaid_ok else '—'))
    for w in warnings: print(w)
    print('\n--- 直接复制给 Workflow 的 args(已绝对路径化) ---')
    args = {'tenderPath': tender, 'outDir': out, 'skillDir': skill_dir}
    if mat: args['materialsDir'] = mat
    print(json.dumps(args, ensure_ascii=False, indent=2))
    print('(演示要快才加 "fast": true——正式交付不要加,fast 会把每章压到 2000–4000 字)')
    sys.exit(0 if tender_ok else 2)


if __name__ == '__main__':
    main()
