#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
标书拼装器 · 把各章/偏离表按序机械拼接成册（省 token 的关键：拼装是确定性活，不该让大模型把全文重抄一遍）
用法：python3 assemble_tender.py --title "投标文件（技术标）" --out 投标文件_技术标.md \
        章节/第1章.md 章节/第2章.md ... 技术应答偏离表.md 商务偏离表.md

- 输出文件首行 `# <title>`；各部分按给定顺序拼接，之间空行分隔。
- 层级归一：某部分若以单 `#` 标题开头（把自己当整册），该部分全部标题自动降一级（# → ##），代码块内不动。
- 打印每部分字数与总字数（主控用来验收"汇总不缩水"）；缺失的部分文件告警并以非 0 退出码结束。
- 拼完后由"汇总员"只做**局部编辑**：文首插对照表、文末补《投标人补料清单》、净化内部痕迹——
  禁止让模型整文重写输出（那是输出 token 的最大浪费源）。
"""
import sys, os, re, argparse


def demote_if_book_level(text):
    """部分文件以单#标题开头 → 全部标题降一级（fence 内不动）"""
    lines = text.splitlines()
    first_heading = None
    fence = False
    for ln in lines:
        if ln.startswith('```'):
            fence = not fence
            continue
        if fence:
            continue
        m = re.match(r'^(#{1,6})\s', ln)
        if m:
            first_heading = len(m.group(1))
            break
    if first_heading != 1:
        return text
    out, fence = [], False
    for ln in lines:
        if ln.startswith('```'):
            fence = not fence
            out.append(ln)
            continue
        if not fence and re.match(r'^#{1,6}\s', ln) and not ln.startswith('#######'):
            out.append('#' + ln)
        else:
            out.append(ln)
    return '\n'.join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--title', required=True, help='册名，如 投标文件（技术标）')
    ap.add_argument('--out', required=True, help='输出的整册 md 路径')
    ap.add_argument('parts', nargs='+', help='按装订顺序排列的部分文件（章节/偏离表/函件等 md）')
    a = ap.parse_args()

    chunks = ['# %s' % a.title.strip()]
    total, missing = 0, []
    for p in a.parts:
        if not os.path.isfile(p):
            print('⚠️ 缺失部分文件（跳过）：%s' % p)
            missing.append(p)
            continue
        text = open(p, encoding='utf-8').read().strip()
        n = len(re.sub(r'\s', '', text))
        total += n
        print('  + %-40s %6d 字' % (os.path.basename(p), n))
        chunks.append(demote_if_book_level(text))
    with open(a.out, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(chunks) + '\n')
    print('已拼装 %d 个部分 → %s（正文合计约 %d 字）' % (len(a.parts) - len(missing), a.out, total))
    print('下一步（汇总员只做局部编辑，禁止整文重写）：文首插全局响应对照表、文末补《投标人补料清单》、净化内部痕迹。')
    if missing:
        print('❌ %d 个部分缺失：%s —— 补齐后重拼。' % (len(missing), '、'.join(missing)))
        sys.exit(1)


if __name__ == '__main__':
    main()
