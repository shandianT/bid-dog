#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
标书格式链路回归测试：md → build_tender_docx.py → docx → check_docx_format.py 自检闭环，
以及 fill_tender_template.py 模板套版的保格式替换。
运行：python3 bid-multiagent-tao/tests/test_format_roundtrip.py   （依赖 pip install python-docx）
"""
import json, os, re, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
REFS = os.path.join(os.path.dirname(HERE), 'references')
BUILD = os.path.join(REFS, 'build_tender_docx.py')
CHECK = os.path.join(REFS, 'check_docx_format.py')
FILL = os.path.join(REFS, 'fill_tender_template.py')

SAMPLE_MD = """# 智慧园区综合管理平台项目

## 项目理解与总体设计
本项目建设**统一的园区管理平台**，实现数据互联互通，见 [平台架构](http://example.com)。

### 建设目标
平台建设覆盖以下目标：

| 序号 | 目标 | 说明 |
|---|---|---|
| 1 | 统一门户 | 单点登录 SSO |
| 2 | 数据中台 | 汇聚 12 类数据源 |

#### 阶段划分
- 第一阶段：基础平台搭建
- 第二阶段：应用接入

## 系统功能响应
针对招标功能需求逐条响应。
"""

CUSTOM_SPEC = {
    "page": {"size": "A4", "margins_cm": {"top": 2.5, "bottom": 2.5, "left": 3.0, "right": 2.5}, "gutter_cm": 1.0},
    "body": {"font": "仿宋_GB2312", "size": "四号", "ascii_font": "Times New Roman",
             "line_spacing": {"rule": "fixed", "pt": 28}, "first_line_indent_chars": 2},
    "headings": {
        "h1": {"font": "黑体", "size": "二号", "bold": True, "align": "center", "numbering": "第{n}章"},
        "h2": {"font": "楷体_GB2312", "size": "三号", "numbering": "{n}.{m}"},
        "h3": {"font": "仿宋_GB2312", "size": "四号", "numbering": "{n}.{m}.{k}"},
    },
    "header": {"text": "{title}·投标文件"},
    "footer": {"format": "{page} / {pages}"},
    "page_numbering": {"body_restart": True, "front_format": "roman"},
    "toc": {"levels": 2, "title": "目  录"},
    "cover": {"subtitle": "投标文件（技术标）", "title_size": "小初",
              "fields": [{"label": "招标编号", "value": "ZB-2026-001"}, {"label": "投标人（盖章）", "value": ""}]},
    "table": {"size": "五号", "align": "center", "ascii_font": "Times New Roman"},
}

TITLE = '智慧园区综合管理平台项目'
PASSED = []

def run(*cmd, expect=0):
    r = subprocess.run([sys.executable, *cmd], capture_output=True, text=True)
    assert r.returncode == expect, 'exit=%d(期望%d)\n%s\n%s' % (r.returncode, expect, r.stdout, r.stderr)
    return r

def ok(name): PASSED.append(name); print('✅ %s' % name)

def test_default_roundtrip(tmp):
    md = os.path.join(tmp, '方案.md'); open(md, 'w', encoding='utf-8').write(SAMPLE_MD)
    docx = os.path.join(tmp, '默认.docx')
    run(BUILD, md, docx, '--title', TITLE)
    run(CHECK, docx, '--title', TITLE)
    assert os.path.exists(os.path.join(tmp, '默认_格式自检报告.md'))
    ok('默认国内标书格式：导出 + 自检全过 + 报告落盘')

def test_custom_spec_roundtrip(tmp):
    from docx import Document
    from docx.oxml.ns import qn
    md = os.path.join(tmp, '方案.md')
    spec = os.path.join(tmp, 'spec.json')
    json.dump(CUSTOM_SPEC, open(spec, 'w', encoding='utf-8'), ensure_ascii=False)
    docx = os.path.join(tmp, '技术标.docx')
    r = run(BUILD, md, docx, '--title', TITLE, '--subtitle', '投标文件（技术标）', '--format-spec', spec)
    assert '生效' not in r.stderr
    run(CHECK, docx, '--title', TITLE, '--format-spec', spec)
    # 直接核对 XML 关键点（不依赖自检器自身）
    d = Document(docx)
    assert len(d.sections) == 2, '封面/目录与正文应分节'
    body = d.sections[1]
    pg = body._sectPr.find(qn('w:pgNumType'))
    assert pg is not None and pg.get(qn('w:start')) == '1', '正文应从第1页重新编号'
    front_pg = d.sections[0]._sectPr.find(qn('w:pgNumType'))
    assert front_pg is not None and front_pg.get(qn('w:fmt')) == 'upperRoman', '前置节应为罗马页码'
    assert abs(d.sections[0].gutter.cm - 1.0) < 0.06, '装订线 1cm'
    rpr = d.styles['Normal'].element.find(qn('w:rPr'))
    rf = rpr.find(qn('w:rFonts'))
    assert rf.get(qn('w:eastAsia')) == '仿宋_GB2312' and rf.get(qn('w:ascii')) == 'Times New Roman', '中西文字体分设'
    h1 = next(p.text for p in d.paragraphs if p.style.name == 'Heading 1')
    assert h1.startswith('第1章'), '标题编号前缀'
    ok('招标自定义格式：导出 + 自检全过 + 分节/页码/装订线/中西文字体/编号核验')
    return docx

def test_check_catches_mismatch(tmp, custom_docx):
    r = run(CHECK, custom_docx, expect=1)   # 用默认 spec 核验自定义格式的文档 → 必须失败
    assert '不符' in r.stdout
    ok('负样本：格式不符时自检器退出码非 0 并列出不符项')

def test_typo_spec_warns(tmp):
    md = os.path.join(tmp, '方案.md')
    bad = os.path.join(tmp, 'typo.json')
    json.dump({"bdy": {"font": "宋体"}, "body": {"siez": "小四"}}, open(bad, 'w', encoding='utf-8'), ensure_ascii=False)
    r = run(BUILD, md, os.path.join(tmp, 'typo.docx'), '--format-spec', bad)
    assert 'bdy' in r.stderr and 'body.siez' in r.stderr, '拼写错误字段应告警'
    ok('spec 拼写错误字段：导出时打印告警')

def test_template_fill_preserves_format(tmp):
    from docx import Document
    tpl = os.path.join(tmp, '模板.docx'); out = os.path.join(tmp, '模板_已填.docx')
    d = Document()
    p = d.add_paragraph()
    p.add_run('致：').bold = True
    r2 = p.add_run('〔采购'); r2.underline = True
    r3 = p.add_run('人名称〕'); r3.underline = True
    p.add_run('：我方 ')
    r5 = p.add_run('{{投标人名称}}'); r5.underline = True
    p.add_run(' 授权 {{被授权人}} 办理投标事宜。')
    sec = d.sections[0]; sec.header.is_linked_to_previous = False
    sec.header.paragraphs[0].add_run('项目：〔项目名称〕')
    d.save(tpl)
    data = os.path.join(tmp, '填充.json')
    json.dump({"采购人名称": "某市大数据局", "投标人名称": "XX科技有限公司", "项目名称": "智慧园区项目"},
              open(data, 'w', encoding='utf-8'), ensure_ascii=False)
    r = run(FILL, tpl, out, '--data', data)
    assert '被授权人' in r.stdout, '未填占位符应被提示'
    d2 = Document(out)
    par = d2.paragraphs[0]
    assert par.text == '致：某市大数据局：我方 XX科技有限公司 授权 {{被授权人}} 办理投标事宜。'
    runs = {r.text: r for r in par.runs if r.text}
    assert runs['致：'].bold and not runs['致：'].underline, '占位符之外的格式不应被动'
    assert runs['某市大数据局'].underline, '跨run占位符替换后应继承下划线(填在空位上)'
    assert runs['XX科技有限公司'].underline, '单run占位符替换后应继承下划线'
    assert d2.sections[0].header.paragraphs[0].text == '项目：智慧园区项目', '页眉占位符应被替换'
    ok('模板套版：跨 run 保格式替换 + 页眉替换 + 未填占位符提示')

def _tiny_png(path, w, h, rgb):
    """纯 stdlib 生成实心 PNG（测试不依赖 PIL）"""
    import struct, zlib
    def chunk(tag, data):
        c = tag + data
        return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)
    raw = b''.join(b'\x00' + bytes(rgb) * w for _ in range(h))
    png = (b'\x89PNG\r\n\x1a\n'
           + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b''))
    open(path, 'wb').write(png)

def test_images_marking(tmp):
    from docx import Document
    ws = os.path.join(tmp, 'img_ws'); imgdir = os.path.join(ws, '素材', '图片')
    os.makedirs(imgdir, exist_ok=True)
    _tiny_png(os.path.join(imgdir, 'arch.png'), 320, 180, (200, 220, 250))
    _tiny_png(os.path.join(imgdir, 'cert.png'), 200, 280, (250, 230, 210))
    open(os.path.join(ws, '素材', '图片索引.md'), 'w', encoding='utf-8').write(
        '| 图片ID | 文件 | 默认图注 | 适用场景 |\n|---|---|---|---|\n'
        '| 产品架构图 | 图片/arch.png | 总体架构图 | 架构 |\n'
        '| 资质-证书 | 图片/cert.png | 认证证书 | 资质 |\n')
    md = os.path.join(ws, '方案.md')
    open(md, 'w', encoding='utf-8').write(
        '# 图片打标项目\n\n## 架构\n\n架构如下。\n\n{{图:产品架构图}}\n\n'
        '再次引用同一张图：\n\n{{图:产品架构图}}\n\n〔图:资质-证书〕\n\n{{图:不存在的ID}}\n\n'
        '## 偏离表\n\n| 要求 | 说明 |\n|---|---|\n| 认证 | {{图:资质-证书}} |\n')
    docx = os.path.join(ws, '图.docx')
    r = run(BUILD, md, docx, '--title', '图片打标项目', '--images-dir', os.path.join(ws, '素材'))
    assert '自动插入 2 张' in r.stdout, r.stdout           # 架构图1次 + 证书1次(去重后)
    assert '不存在的ID' in r.stdout, '缺图应汇总提醒'
    d = Document(docx)
    NS = '{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}inline'
    assert len(d.element.body.findall('.//' + NS)) == 2, '同图去重后全文应只嵌2张'
    texts = [p.text for p in d.paragraphs]
    assert any(t.startswith('（见图1') for t in texts), '同图第二次出现应改写为"（见图N）"引用'
    assert any('需人工插入' in t for t in texts), '缺图应留占位'
    assert any(t.startswith('图1 ') for t in texts), '图注应带默认标题'
    cell_txt = d.tables[0].rows[1].cells[1].text
    assert '见图' in cell_txt, '表格里重复引用同图应为"（见图N）"'
    run(CHECK, docx, '--title', '图片打标项目')            # 图片提示行不应影响门禁
    r2 = run(BUILD, md, os.path.join(ws, '图_重复.docx'), '--title', '图片打标项目',
             '--images-dir', os.path.join(ws, '素材'), '--repeat-images')
    assert '自动插入 4 张' in r2.stdout, r2.stdout         # 不去重：架构×2 + 证书正文 + 证书表格
    ok('图片打标：索引解析 + 同图去重"见图N" + 缺图占位 + 表格嵌图 + 门禁不受影响')

def test_template_fill_image_slot(tmp):
    from docx import Document
    ws = os.path.join(tmp, 'img_ws')   # 复用上一用例的素材库
    tpl = os.path.join(ws, '模板.docx'); out = os.path.join(ws, '模板_图.docx')
    d = Document()
    p = d.add_paragraph()
    p.add_run('附：').bold = True
    r2 = p.add_run('{{图:资质-证书}}'); r2.underline = True
    p.add_run('（复印件加盖公章）')
    d.save(tpl)
    r = run(FILL, tpl, out, '--images-dir', os.path.join(ws, '素材'))
    assert '自动插入 1 张' in r.stdout, r.stdout
    d2 = Document(out)
    NS = '{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}inline'
    assert len(d2.element.body.findall('.//' + NS)) == 1, '模板槽位应原位插图'
    par = d2.paragraphs[0]
    assert par.text.startswith('附：') and par.text.endswith('（复印件加盖公章）'), '槽位前后文字应原样保留'
    assert par.runs[0].text == '附：' and par.runs[0].bold, '槽位之外 run 的格式不应被动'
    ok('模板套版图片槽位：跨 run 原位插图 + 周围文字与格式零改动')

def test_check_catches_foreign_export(tmp):
    """负样本：不走 build_tender_docx.py 的"野路子导出"(pandoc/裸python-docx——Word默认样式:
    Calibri正文+蓝色标题,现场表现为"颜色字体都没匹配到")必须被门禁拦下。"""
    from docx import Document
    d = Document()                       # 默认模板 = Calibri/蓝色 Heading,无封面目录页眉页脚
    d.add_heading('项目理解与总体设计', level=1)
    d.add_paragraph('这是没有走导出脚本的文档。')
    foreign = os.path.join(tmp, '野路子.docx')
    d.save(foreign)
    r = run(CHECK, foreign, expect=1)
    assert '不符' in r.stdout
    assert '颜色' in r.stdout or '字体' in r.stdout, '应指出字体/颜色与标书格式不符'
    ok('负样本：pandoc/裸python-docx 野路子导出（蓝标题/Calibri）被门禁拦截')

def main():
    with tempfile.TemporaryDirectory() as tmp:
        test_default_roundtrip(tmp)
        custom_docx = test_custom_spec_roundtrip(tmp)
        test_check_catches_mismatch(tmp, custom_docx)
        test_typo_spec_warns(tmp)
        test_template_fill_preserves_format(tmp)
        test_images_marking(tmp)
        test_template_fill_image_slot(tmp)
        test_check_catches_foreign_export(tmp)
    print('\n全部通过：%d 组用例' % len(PASSED))

if __name__ == '__main__':
    main()
