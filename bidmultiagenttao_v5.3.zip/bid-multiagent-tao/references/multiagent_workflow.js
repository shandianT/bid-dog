// ⚠️ 双路径同步维护规则：本文件（路径A）与 角色提示词.md（路径B）是**同一套角色的两个载体**——
//    组成规划/格式提取/评分废标/入库/拆解/撰写/应答/汇总/配图/验证 的提示词在两边各有一份。
//    改任何一侧的角色逻辑，必须同步改另一侧对应角色（对照表见 升级说明与操作手册.md《双路径同步对照表》），
//    否则两条路径会漂移出不同的输出效果。仅单侧存在的机制（effort降档/economy=仅A；共享盘测试/直传模式=仅B）见对照表说明。
// 多 Agent 投标标书生成 · 生产化版 v5
// v5 变化(针对"读不到素材/内容变薄/格式不对"三类现场问题)：
//   ① 新增阶段0预检：确定性定位素材库+清点内容,读不到素材当场大声报警,不再静默降级成占位版
//   ② fast 默认关闭：不传 fast 就是正式节奏(每章有字数下限);演示要快必须显式传 fast:true
//   ③ 撰写后加"字数验收"回路：逐章核对文件真实字数,不达标的章节自动重写扩写一轮
//   ④ 提示词按角色瘦身：分析类角色不再被灌入打标/配图规则,无图片索引时全员不注入打标规则
//   ⑤ 出Word 加铁律：只准用 references 脚本导出,禁止 pandoc/自写代码兜底(那是"格式不对"的头号来源)
// 由 SKILL.md 通过 Workflow 工具调用：Workflow({ scriptPath: 本文件, args: { tenderPath, outDir, skillDir, materialsDir, fast } })
// args.skillDir = 本 skill 目录绝对路径（预检与出 Word 都要用 references/ 下脚本;不传则跳过出 Word）
export const meta = {
  name: 'bid-multiagent',
  description: '多Agent并行生成投标书：预检→前置分析→拆解→分章并行撰写(字数验收)→偏离表→按组成汇总→验证自检→出Word+格式自检',
  phases: [
    { title: '预检', detail: '素材库定位+清点、招标文件体检、依赖检查;有图无索引→自动OCR入库建索引' },
    { title: '前置分析', detail: '组成识别+格式提取+评分/废标分析(3个Agent并行)' },
    { title: '拆解', detail: '以投标文件组成为骨架→响应矩阵+章节大纲(技术部分≤6章)' },
    { title: '撰写', detail: 'N个撰写Agent并行各写一章→逐章字数验收,不达标自动扩写' },
    { title: '应答', detail: '据产品能力表出技术偏离表+商务偏离表(逐条是否满足)' },
    { title: '汇总净化', detail: '按组成顺序拼装(可分技术/商务/报价册)→干净交付稿' },
    { title: '验证自检', detail: '覆盖率+组成完整性+废标规避+评分点覆盖→自检报告' },
    { title: '出Word', detail: '只用references脚本导出docx→check_docx_format格式门禁,不过则修正重导' },
  ],
}

const A = (typeof args !== 'undefined' && args) ? args : {}
const TENDER = A.tenderPath
const OUT = A.outDir || './投标输出'
const SKILL_DIR = A.skillDir || ''   // 预检与出 Word 阶段需要；空则预检降级为 ls、跳过出 Word
const FAST = A.fast === true         // v5：默认正式节奏；演示要快必须显式传 fast:true
const ECONOMY = A.economy === true   // v5.2 省钱模式：砍冗余不砍内容(章数上限5/每章≥3000/跳过独立配图复核)
const CAP = A.maxChapters || (ECONOMY ? 5 : 6)
const MIN_WORDS = A.minChapterWords || (FAST ? 2000 : (ECONOMY ? 3000 : 3500))   // 每章字数验收线
const LEN = FAST
  ? '本章 2000–4000 字（演示节奏，写满要点即可，不堆字）'
  : `本章不少于 ${MIN_WORDS} 字：每个响应点都展开成可操作内容(做法/步骤/参数/SLA/量化指标/证明思路)，禁止一句话带过；先保证逐条覆盖，再保证展开深度`

// ---------- 阶段0：预检（确定性体检——素材读不到、路径不对在这里当场暴露） ----------
phase('预检')
const PRE_SCHEMA = { type: 'object', additionalProperties: false,
  required: ['materials_dir', 'materials_found', 'has_image_index', 'image_count', 'tender_ok', 'notes'],
  properties: {
    materials_dir: { type: 'string', description: '真实存在的素材库绝对路径；没找到则空字符串' },
    materials_found: { type: 'array', items: { type: 'string' }, description: '素材库里实际存在的推荐文件名' },
    has_image_index: { type: 'boolean', description: '是否有 图片索引.md(自动配图开关)' },
    image_count: { type: 'number', description: '素材库图片张数(图片/目录或根目录下的图像文件)' },
    tender_ok: { type: 'boolean', description: '招标文件存在且可直接精读(md/txt);pdf/docx未转换=false' },
    notes: { type: 'string', description: '警告与说明(素材缺什么/招标文件要不要先转md/依赖缺什么)' } } }
const pre = await agent(
  `你是流程预检员，只做确定性检查、不做任何生成。\n` +
  (SKILL_DIR
    ? `优先执行：python3 ${SKILL_DIR}/references/preflight_check.py --tender "${TENDER}" --out "${OUT}"` +
      (A.materialsDir ? ` --materials "${A.materialsDir}"` : '') + ` --json\n把它输出的 JSON 如实映射为结构化结果返回。\n`
    : '') +
  `若 python3 不可用，改用 ls 手工检查并如实返回：\n` +
  `1) 素材库按候选顺序找第一个真实存在的目录：${A.materialsDir ? `"${A.materialsDir}" > ` : ''}<招标文件同目录>/素材 > ./素材 > ./演示素材包 > ${OUT}/素材；` +
  `列出其中实际存在的文件（公司介绍.md/产品资料.md/产品能力表.md/资质与案例.md/应答要点.md/图片索引.md/图片/）。\n` +
  `2) 招标文件 ${TENDER}：存在？非空？md/txt 可直读，pdf/docx/zip 必须先转换(tender_ok=false 并在 notes 说明)。\n` +
  `3) mkdir -p ${OUT}/章节 建好工作空间。绝不臆造检查结果——找不到就如实说找不到。`,
  { label: '00预检', phase: '预检', schema: PRE_SCHEMA, effort: 'low' })   // 纯机械检查,低推理档足够
const MAT = (pre && pre.materials_dir) ? pre.materials_dir : (A.materialsDir || (OUT + '/素材'))
const MAT_OK = !!(pre && pre.materials_dir)
let HAS_IMG_INDEX = !!(pre && pre.has_image_index)
const IMG_COUNT = (pre && pre.image_count) || 0
const MAT_LIST = (pre && pre.materials_found && pre.materials_found.length) ? pre.materials_found.join('、') : '(空)'
if (MAT_OK) log(`✅ 素材库：${MAT}｜已有：${MAT_LIST}｜图片：${IMG_COUNT}张｜图片索引：${HAS_IMG_INDEX ? '有(自动配图开)' : '无'}`)
else log(`⚠️⚠️ 未找到素材库——偏离表将是占位版、章节缺真实弹药，内容会明显变薄。建议停下来按 素材模板_投标方信息.md 建库(或传 materialsDir 指向真实位置)后重跑。本次继续则全部〔需补充〕占位。`)
if (pre && pre.tender_ok === false) log(`⚠️⚠️ 招标文件不可直读：${pre.notes || 'PDF/扫描件需先转成 招标文件_解析版.md(正文+全部附件)再重跑，否则分析全靠猜。'}`)
if (pre && pre.notes) log(`预检备注：${String(pre.notes).slice(0, 300)}`)

// ---------- 阶段0.5：图片素材入库（v5：有图无索引不再"可选"，自动补建——图插错位置的根源就在没索引） ----------
let ingest = null
if (MAT_OK && !HAS_IMG_INDEX && IMG_COUNT > 0) {
  const INGEST_SCHEMA = { type: 'object', additionalProperties: false,
    required: ['indexed', 'filled', 'uncertain', 'sensitive', 'by_filename_only', 'renamed'],
    properties: {
      indexed: { type: 'number', description: '登记进 图片索引.md 的图片数' },
      filled: { type: 'number', description: '回填到 产品能力表.md"配图"列的条数' },
      uncertain: { type: 'number', description: '〔待确认〕数(看不清/没把握)' },
      sensitive: { type: 'number', description: '疑似含真实客户名/敏感信息需脱敏的图片数' },
      by_filename_only: { type: 'boolean', description: '无视觉能力,仅按文件名建的低置信索引=true' },
      renamed: { type: 'number', description: '语义化改名张数(哈希名→图片ID.扩展名;跑不了脚本填0)' } } }
  ingest = await agent(
    `你是图片素材入库员（角色⓪D）。素材库 ${MAT}/ 有 ${IMG_COUNT} 张图片但没有 图片索引.md——没有索引，撰写/应答就只能瞎猜配图，图会插错位置。\n` +
    `任务：**逐张打开查看图片内容（OCR 读出图内文字）**，新建 ${MAT}/图片索引.md，表结构（新五列）：\n` +
    `| 图片ID | 文件 | 默认图注 | 类别 | 图内文字摘要 | 适用场景/关键词 | 落位锚点 |\n` +
    `- 图片ID 用"类别-业务名"（如 资质-ISO9001、功能截图-代码扫描、架构-总体架构），稳定命名；\n` +
    `- 类别只能从固定枚举里选：架构图 / 功能截图 / 资质证书 / 案例证明 / 人员证书 / 其他；\n` +
    `- 图内文字摘要 = OCR 读到的关键文字（证书全名/界面标题/图表标题），看不清写〔待确认:文件名〕；\n` +
    `- 落位锚点 = 这张图**只允许**插到哪类位置（如"总体架构章·概述段后"/"资质证明章"/"仅偏离表证明材料列"），后续配图员只按锚点插；\n` +
    `- 图注写成正式标书口径（如"ISO9001质量管理体系认证证书"）。\n` +
    `若 ${MAT}/产品能力表.md 存在：按功能名称与截图内容匹配，把**有把握的**"配图"列回填图片ID；没把握的不填；只动"配图"列。\n` +
    `疑似含真实客户名/敏感信息的图片单独列出建议脱敏（不自行删除）。\n` +
    (SKILL_DIR ? `建完索引后**语义化改名**（把打标痕迹落到文件名上，便于素材库长期复用）：执行 ` +
      `python3 ${SKILL_DIR}/references/organize_images.py "${MAT}" --apply —— 哈希/随机文件名批量改成 图片ID.扩展名，` +
      `索引"文件"列自动同步并留 _重命名记录.md；python 跑不了则跳过（不影响复用），renamed 如实填改名张数。\n` : '') +
    `⚠️ 如果你没有查看图片内容的能力：只按文件名建低置信索引（每行图注后加〔待确认〕），by_filename_only 如实返回 true——绝不假装看过图。返回结构化结果。`,
    { label: '04图片入库', phase: '预检', schema: INGEST_SCHEMA })
  if (ingest && ingest.indexed > 0) {
    HAS_IMG_INDEX = true
    log(`图片入库：登记 ${ingest.indexed} 张｜回填配图列 ${ingest.filled} 条｜语义化改名 ${ingest.renamed || 0} 张｜〔待确认〕${ingest.uncertain}｜敏感 ${ingest.sensitive}${ingest.by_filename_only ? '｜⚠️仅按文件名(低置信,建议人工核对索引后重跑配图)' : ''}`)
  } else {
    log('图片入库未产出索引——本次不自动配图')
  }
}

// ---------- 规则按角色裁剪（v5：分析员不灌打标规则；无图片索引全员不灌打标规则） ----------
const RULES_LITE = `
硬规则（必守）：
- 防泄露：采购人一律写〔采购人〕，严禁写出任何真实单位名称（包括你推断的）；只依据招标文件原文。
- 不编造：招标文件里没有的信息不臆造；拿不准的标注出来。`
const RULES_MAT = MAT_OK
  ? `素材读取（关键）：素材库=${MAT}（预检已确认存在，含：${MAT_LIST}）。写作/应答前**先读相关素材文件**，据实采用真实信息（产品能力表.md 优先级最高）；缺项标〔需补充〕，绝不编造。素材回执：返回结果必须如实反映你是否真的读到了素材文件——读不到就如实报告，不许沉默跳过。\n`
  : `素材提醒：素材库未找到——凡涉及我方（投标人）身份/产品/资质/案例一律〔需补充〕占位 + 中性成句，绝不编造。\n`
const RULES_IMG = HAS_IMG_INDEX
  ? `图片打标（自动配图）：${MAT}/图片索引.md 存在。讲到对应产品能力/架构/资质/案例处独立成行写 {{图:图片ID}}（{{图:ID|图注}} 可自定义图注），出Word时自动替换成素材真图并编号图注；**ID只能用索引里登记的，不得虚构**；索引没有但确实需要配图处写〔配图建议:说明〕；打标前后要有一句引出图的正文。\n` +
    `配图匹配优先级（逐条应答必须走1，不得临场猜）：1.产品能力表"配图"列——响应到哪条能力就用该行绑定的图片ID；2.应答要点.md 写死的条款配图；3.图片索引"适用场景/关键词"（仅章节级）。同一图片ID可被多处重复打标（导出自动去重为"见图N"引用）。\n`
  : ''
const RULES = `\n${RULES_MAT}${RULES_IMG}硬规则（必守）：
- 零漏点：分配给本单元的每条要求都要正文响应；"包括但不限于"的子项、标题括号并列词逐条落地，不得只点名不展开。
- 不得引用不存在的章节：只引用本方案确实写出的内容，禁止"详见第X章"指向未产出章节。
- 防泄露：采购人一律写〔采购人〕，**严禁写出任何真实单位名称**（包括你从行业/上下文推断的名字）；只依据招标文件原文。
- 不编造：投标人(我方)身份/资质/案例/人员/财务未知→用〔需补充〕占位+中性成句；AI生成的具体数字标〔参数待核实〕。
- 成品纯净：交付正文用业务语言，小节标题纯业务名，不写内部ID/自评/⚠️。
- 承诺函成品口径：招标随附的函模板/必备格式件必须生成成品正文，硬性数字写确定值。
- 流程性内容配 Mermaid 图。
- 写完自查：产物必须真实写入指定文件；自报字数前先统计文件真实字数，不符就继续补写。`

// ---------- 阶段1：前置分析（3 个 Agent 并行） ----------
phase('前置分析')
const COMP_SCHEMA = { type: 'object', additionalProperties: false,
  required: ['volumes', 'items', 'templated'],
  properties: {
    volumes: { type: 'array', items: { type: 'string' }, description: '要求的分册,如["技术标","商务标","报价标"];未要求分册则["单册"]' },
    items: { type: 'number', description: '投标文件组成清单项数' },
    templated: { type: 'number', description: '招标附件给了模板的格式件数' } } }
const FMT_SCHEMA = { type: 'object', additionalProperties: false,
  required: ['rules_found', 'manual_items'],
  properties: { rules_found: { type: 'number', description: '提取到的格式要求条数' },
    manual_items: { type: 'number', description: 'Word无法承载的人工事项数(胶装/骑缝章等)' } } }
const SCORE_SCHEMA = { type: 'object', additionalProperties: false,
  required: ['score_items', 'total_score', 'high_priority', 'veto_items'],
  properties: { score_items: { type: 'number' }, total_score: { type: 'number' },
    high_priority: { type: 'number', description: '标【高】的评分点数' }, veto_items: { type: 'number', description: '废标/否决条款数' } } }

const [comp, fmt, score] = await parallel([
  () => agent(
    `你是投标文件目录规划专家。通读招标文件(含附件/投标文件格式/评标办法)：${TENDER}\n${RULES_LITE}\n` +
    `识别招标要求提交的完整投标文件组成，写入 ${OUT}/投标文件组成.md：` +
    `①分册判定(技术标/商务标/报价标/资格审查,引用条款佐证;未明确→单册并注明);` +
    `②组成清单表|序号|文件/章节名称|所属分册|招标依据|是否有指定模板|谁产出|——逐项核对投标函/开标一览表/法人身份证明/授权委托书/报价表/商务偏离/技术偏离/资格证明/实施方案/售后/业绩/人员表/承诺函,招标没要求的不列、额外要求的补列;` +
    `③附件模板登记:招标附件给的响应表/函件模板逐个登记(名称/位置/正文原样抄录),按招标规定顺序排列=最终装订顺序;` +
    `④格式件成品化清单:哪些AI可生成成品、哪些必须人工提供。返回结构化结果。`,
    { label: '01组成规划', phase: '前置分析', schema: COMP_SCHEMA }),
  () => agent(
    `你是标书格式专家。通读招标文件"投标文件编制/制作/格式/装订要求"条款：${TENDER}\n` +
    `把Word格式要求提取为 ${OUT}/word_format_spec.json(严格JSON)。字段:page{size,orientation,margins_cm,gutter_cm装订线}/body{font,size,ascii_font西文字体,align,line_spacing,first_line_indent_chars}/headings{h1..h4:{font,size,bold,align,numbering}}/header{enabled,text,align}/footer{enabled,format,align}/page_numbering{body_restart正文从1重新编页,front_format:"roman"或null,start_at}/toc{enabled,levels,title}/cover{enabled,subtitle,title_size,subtitle_size,info_font,info_size,fields[{label,value}]封面要素,show_date}/table{style,font,ascii_font,size,align,header_bold}/figure_caption{enabled,style}/attachments_order[]。` +
    `字号可写中文("小四")或磅数;footer.format 可用 {page}/{pages};h1.numbering 如 "第{n}章"。` +
    `常见表述对照:'页码从1开始/封面不编页码'→page_numbering;'数字英文用Times New Roman'→ascii_font;'装订线X厘米'→gutter_cm;'行距28磅'→{"rule":"fixed","pt":28};'两端对齐'→align:"justify"。` +
    `铁律（v5加重申，这是"格式不像国内标书"的头号来源）:**只写招标书明确逐字规定的字段**,没规定的字段整个省略——脚本会自动用国内标书默认格式(宋体小四/黑体标题/1.5倍距/两端对齐/封面目录)补齐,这个默认就是正确答案;` +
    `**拿不准 = 不写**,宁可全空 {} 也不臆造;绝不因为"看起来专业"而自行加字段;字段名严格按上表拼写;全文无格式要求→只写{}。` +
    `同时写 ${OUT}/格式要求摘要.md:逐条摘录格式/装订/密封/份数要求(注明条款出处),注明哪些进JSON、哪些是人工事项。写完自查JSON可解析。返回结构化结果。`,
    { label: '02格式提取', phase: '前置分析', schema: FMT_SCHEMA }),
  () => agent(
    `你是评标专家。精读招标评标办法/评分标准/否决条款：${TENDER}\n${RULES_LITE}\n` +
    `产出:①${OUT}/评分点响应矩阵.md:|序号|评分项|分值|评分细则(原文摘要)|映射到投标书章节|得分策略|优先级|——商务/技术/价格分逐项提取一分不漏,分值合计对得上总分;分值≥5或客观分(证书/业绩)标【高】;文末给客观分硬材料清单。` +
    `②${OUT}/废标风险清单.md:|序号|条款(原文摘录)|类型|对应投标书位置|规避动作|状态|——全文检索"无效/废标/否决/不予受理/实质性/★/▲"逐条列出,状态初始〔待核对〕。返回结构化结果。`,
    { label: '03评分废标', phase: '前置分析', schema: SCORE_SCHEMA }),
])
const volumes = (comp && comp.volumes && comp.volumes.length) ? comp.volumes : ['单册']
log(`组成:${comp ? comp.items : '?'}项/${volumes.join('+')}｜格式要求:${fmt ? fmt.rules_found : 0}条｜评分点:${score ? score.score_items : 0}项(高优${score ? score.high_priority : 0})｜废标条款:${score ? score.veto_items : 0}条`)

// ---------- 阶段2：拆解 ----------
phase('拆解')
const PLAN_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['domain', 'total_points', 'outline', 'supplement_count'],
  properties: {
    domain: { type: 'string' }, total_points: { type: 'number' },
    outline: { type: 'array', items: { type: 'object', additionalProperties: false, required: ['title', 'must_cover'],
      properties: { title: { type: 'string', description: '纯业务章节名,不带"第N章"' },
        must_cover: { type: 'string', description: '本章必须逐条响应的招标要求+承接的评分点' } } } },
    supplement_count: { type: 'number' },
  },
}
const plan = await agent(
  `你是资深投标方案专家。读招标文件：${TENDER}，以及 ${OUT}/投标文件组成.md、${OUT}/评分点响应矩阵.md。\n${RULES_LITE}\n` +
  `任务：①判定领域；②把招标全部要求拆成原子响应点，建"响应矩阵"+"全局对照表"；` +
  `③设计大纲——**以投标文件组成清单为骨架**(组成要求的每个文件/章节都要有归属)，技术方案部分**不超过${CAP}章**，性质相近合并。` +
  `每章给：纯业务标题、must_cover(逐条响应哪些要求+承接哪些评分点——写全，这是撰写员唯一的任务书)。写入 ${OUT}/00_响应矩阵.md。\n` +
  `④【省token关键】为每章抽取招标原文切片：把与该章 must_cover 相关的招标原文段落(含表格,**原样摘录不改写**)写入 ` +
  `${OUT}/章节切片/第N章_招标摘录.md——撰写员将只读切片不再精读招标全文，漏抽一段=撰写员看不见那段要求，必须抽全。返回结构化结果。`,
  { label: '05拆解', phase: '拆解', schema: PLAN_SCHEMA }
)
const chapters = (plan && plan.outline ? plan.outline : []).slice(0, CAP)
log(`领域=${plan ? plan.domain : '?'}｜${plan ? plan.total_points : 0} 个响应点｜${chapters.length} 章并行撰写｜每章验收线≥${MIN_WORDS}字`)

// ---------- 阶段3：并行撰写 + 字数验收（v5：不达标自动扩写一轮） ----------
phase('撰写')
const CH_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['chapter', 'words', 'mermaid', 'covered', 'materials_read', 'inbody_internal_id', 'real_name_leak'],
  properties: {
    chapter: { type: 'string' }, words: { type: 'number', description: '文件真实字数(写完统计文件,不许估)' },
    mermaid: { type: 'number' },
    covered: { type: 'string' },
    materials_read: { type: 'boolean', description: '是否真实读到并使用了素材文件(读不到/没有素材=false,如实填)' },
    inbody_internal_id: { type: 'number' }, real_name_leak: { type: 'number' },
  },
}
const writePrompt = (c, i, redo) =>
  `你是投标方案撰写专家。\n${RULES}\n` +
  (redo ? `【扩写任务】${OUT}/章节/第${i + 1}章.md 已有初稿但字数不达标(验收线≥${MIN_WORDS}字)。读回现稿，**用文件局部编辑追加/插入内容，禁止整文重新输出**；在不删改已覆盖要点的前提下逐点扩写补深：补做法/步骤/参数/SLA/量化指标/证明思路，直至达标。\n`
     : `撰写【第${i + 1}章 ${c.title}】，仅产出本章正文。**逐条响应以下全部要求(一条不漏)**：\n${c.must_cover}\n`) +
  `【省token的读料顺序，够用就别多读】①${OUT}/章节切片/第${i + 1}章_招标摘录.md(本章相关招标原文,优先读这个)；` +
  `②${OUT}/评分点响应矩阵.md、废标风险清单.md 中映射到本章的行：【高】优先级必须重点展开(篇幅加倍/量化指标/证明思路)，涉及本章的否决项逐条显式响应；` +
  `③素材库相关文件；④仅当切片缺失、或 must_cover 里的要求在切片中找不到原文时，才去招标全文 ${TENDER} 查对应部分补差。\n` +
  `篇幅：${LEN}。章首附"本章响应小表"；流程配Mermaid；承诺函按成品口径。采购人写〔采购人〕。\n` +
  `写入 ${OUT}/章节/第${i + 1}章.md（本章正文从 "## ${c.title}" 一级开始，方便汇总统一层级）。写完统计文件真实字数、如实填 materials_read，再返回结构化结果。`
const written = await parallel(chapters.map((c, i) => () =>
  agent(writePrompt(c, i, false),
    { label: `06撰写第${i + 1}章`, phase: '撰写', schema: CH_SCHEMA })
))
// 字数验收：不信自报，读文件核实；不达标的章节扩写一轮
const AUDIT_SCHEMA = { type: 'object', additionalProperties: false,
  required: ['chapters'],
  properties: { chapters: { type: 'array', items: { type: 'object', additionalProperties: false,
    required: ['no', 'exists', 'words'],
    properties: { no: { type: 'number' }, exists: { type: 'boolean' },
      words: { type: 'number', description: '文件真实字数(wc -m 或等价方式统计)' } } } } } }
const audit = await agent(
  `你是字数核验员，只核对不写作。逐个检查 ${OUT}/章节/第1章.md … 第${chapters.length}章.md：文件是否存在、真实字数是多少` +
  `（必须用 wc -m 或读文件统计，禁止凭印象）。如实返回每章 {no, exists, words}。`,
  { label: '06字数验收', phase: '撰写', schema: AUDIT_SCHEMA, effort: 'low' })   // 只跑 wc,低推理档
const auditRows = (audit && audit.chapters) ? audit.chapters : []
const thin = auditRows.filter(r => !r.exists || (r.words || 0) < MIN_WORDS).filter(r => r.no >= 1 && r.no <= chapters.length)
if (thin.length) {
  log(`⚠️ ${thin.length} 章未过验收线(${thin.map(r => `第${r.no}章${r.exists ? r.words + '字' : '缺文件'}`).join('、')})，自动重写/扩写一轮`)
  await parallel(thin.map(r => () =>
    agent(writePrompt(chapters[r.no - 1], r.no - 1, r.exists),
      { label: `06扩写第${r.no}章`, phase: '撰写', schema: CH_SCHEMA })))
}
const ok = written.filter(Boolean)
const realWords = auditRows.reduce((s, r) => s + (r.words || 0), 0)
log(`并行撰写完成 ${ok.length}/${chapters.length} 章，核验字数约 ${realWords} 字${thin.length ? `（含 ${thin.length} 章扩写后另计）` : ''}`)

// ---------- 阶段4：偏离表 ----------
phase('应答')
const RESP_SCHEMA = { type: 'object', additionalProperties: false,
  required: ['total', 'met', 'partial', 'unmet', 'biz_deviations', 'materials_used'],
  properties: { total: { type: 'number' }, met: { type: 'number' }, partial: { type: 'number' },
    unmet: { type: 'number' }, biz_deviations: { type: 'number', description: '商务偏离条数' },
    materials_used: { type: 'boolean', description: '是否真实读到并使用了产品能力表/产品资料(没读到=false,偏离表为占位版)' } } }
const resp = await agent(
  `你是技术应答专家。读招标文件 ${TENDER} 与 ${MAT}/产品能力表.md(优先)、产品资料.md、应答要点.md(若有)。${RULES}\n` +
  `①${OUT}/技术应答偏离表.md:|序号|招标要求(摘要)|我方应答|满足情况|说明|——功能/技术/服务要求逐条不合并;` +
  `判定依据:能力表"支持"→满足(引证明材料);"需定制/版本受限"→部分满足+弥补方案;"不支持"→不满足(不假装);未覆盖→〔需补充:产品确认〕。` +
  (HAS_IMG_INDEX ? `应答配图:能力表有"配图"列时,命中的能力行绑了图片ID的在"说明"列末尾打标{{图:该ID}}(配图跟命中的能力条目走,不自行挑图;同图多条重复打标正常,导出自动去重)。` : '') +
  `②${OUT}/商务偏离表.md:|序号|招标商务条款|我方响应|有无偏离|偏离说明|——交付期/付款/质保/违约/保密逐条,默认无偏离。` +
  `招标附件给了偏离表模板(见 ${OUT}/投标文件组成.md)→按招标模板列结构输出。如实返回 materials_used。返回结构化结果。`,
  { label: '07应答偏离', phase: '应答', schema: RESP_SCHEMA })
log(`技术应答:共${resp ? resp.total : 0}条(满足${resp ? resp.met : 0}/部分${resp ? resp.partial : 0}/不满足${resp ? resp.unmet : 0})｜商务偏离${resp ? resp.biz_deviations : 0}条｜素材${resp && resp.materials_used ? '已用✅' : '未读到⚠️(占位版)'}`)

// ---------- 阶段5：按组成汇总 ----------
phase('汇总净化')
const AGG_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['delivery_files', 'total_words', 'dirty_scan_pass'],
  properties: { delivery_files: { type: 'array', items: { type: 'string' }, description: '产出的交付稿文件路径(分册则多个)' },
    total_words: { type: 'number' }, dirty_scan_pass: { type: 'boolean' } },
}
const agg = await agent(
  `你是汇总+净化Agent（省token模式：机械拼装交给脚本，你只做判断与**局部编辑**）。读 ${OUT}/投标文件组成.md + 00_响应矩阵.md（先不必读章节全文）。\n` +
  `步骤1 定册与顺序：按组成清单决定分册(${volumes.join('/')})与每册包含的部分文件及先后顺序（章节/第1..${chapters.length}章.md、技术应答偏离表.md、商务偏离表.md 等；含 attachments_order 附件顺序）。\n` +
  (SKILL_DIR
    ? `步骤2 脚本拼装（**禁止自己把全文抄一遍**）：对每册执行 python3 ${SKILL_DIR}/references/assemble_tender.py --title "<册名>" --out ${OUT}/<册文件.md> <按序部分文件...>；脚本自动统一标题层级并打印各部分字数与合计（total_words 取脚本打印值）。要求分册→技术方案+技术偏离归技术标、商务响应+商务偏离+资格函件归商务标、报价归报价标；单册→${OUT}/投标技术方案.md。\n`
    : `步骤2 拼装：按顺序把各部分拼进每册文件，**逐字保留各章正文，禁止删节压缩**；统一标题层级(每册第一行 "# 册名"，各章 "## 章名" 起)。\n`) +
  `步骤3 增补与净化（**只用文件局部编辑，禁止整文重新输出**）：每册文首插入全局响应对照表(只引用实际存在的章节)，文末追加《投标人补料清单》(占位项+评分矩阵硬材料+必须人工提供的格式件+人工确认点:投标人名称/报价/资质/案例/签章)；就地删内部痕迹(自评/内部ID/⚠️)、真实单位名替回〔采购人〕；{{图:...}}/![]()图片打标**原样保留**，〔配图建议:...〕列入补料清单。返回结构化结果。`,
  { label: '08汇总净化', phase: '汇总净化', schema: AGG_SCHEMA }
)
const deliveryFiles = (agg && agg.delivery_files && agg.delivery_files.length) ? agg.delivery_files : [OUT + '/投标技术方案.md']
log(`汇总完成：${deliveryFiles.length} 册，${agg ? agg.total_words : 0} 字，脏词门禁 ${agg && agg.dirty_scan_pass ? '通过✅' : '未过'}`)

// ---------- 阶段5.5：配图复核（自动打标；无图片索引直接跳过；economy 模式跳过——写作时已按能力表打标,损失很小） ----------
let tag = null
if (HAS_IMG_INDEX && !ECONOMY) {
  const TAG_SCHEMA = { type: 'object', additionalProperties: false,
    required: ['tagged', 'fixed', 'suggestions'],
    properties: { tagged: { type: 'number', description: '新增图片打标数' },
      fixed: { type: 'number', description: '校正的无效打标数' },
      suggestions: { type: 'number', description: '留给人工的〔配图建议〕数' } } }
  tag = await agent(
    `你是配图员（自动打标）。读 ${MAT}/图片索引.md（打标唯一合法ID来源）+ ` +
    `${MAT}/产品能力表.md（"配图"列）+ 交付稿 ${deliveryFiles.join('、')}，通读后**用文件局部编辑加标/校正标（禁止整文重新输出），不改原有文字**。\n` +
    `插图位置按确定性优先级，禁止"感觉贴切"就插：\n` +
    `①逐条应答/偏离表：命中能力行"配图"列有ID的在该条说明末尾补{{图:该ID}}（同图多行重复打标正常，导出自动去重为"见图N"）；\n` +
    `②章节级：索引有"落位锚点"列的图**只允许插在锚点指定的位置**（锚点写"仅偏离表证明材料列"的绝不进正文章节）；` +
    `无锚点列的旧索引才按"适用场景/关键词"匹配章节标题，且插在该章节引出段之后、独立成行（可补一句引出正文）；\n` +
    `③已有打标ID不在索引的就近改为正确ID，没有合适的降级〔配图建议:…〕；④拿不准不打，绝不虚构ID，封面/目录/函件落款/投标函不打标。\n` +
    `最后写 ${OUT}/配图清单.md：| 图片ID | 插入位置(册/章/小节或"偏离表第N条") | 依据(配图列/锚点/关键词) |——给人工快速核对图有没有插错地方。返回结构化结果。`,
    { label: '09配图复核', phase: '汇总净化', schema: TAG_SCHEMA })
  log(`配图复核：新增打标 ${tag ? tag.tagged : 0} 处｜校正 ${tag ? tag.fixed : 0}｜配图建议 ${tag ? tag.suggestions : 0}｜位置核对表：配图清单.md`)
} else if (!HAS_IMG_INDEX) {
  log('无图片索引.md → 跳过配图复核（要自动配图：先让"角色⓪D 图片素材入库员"建索引）')
} else {
  log('economy 模式 → 跳过独立配图复核（撰写/应答时已按能力表配图列打标）')
}

// ---------- 阶段6：验证 + 自检报告 ----------
phase('验证自检')
const VERIFY_SCHEMA = {
  type: 'object', additionalProperties: false,
  required: ['verdict', 'coverage_pct', 'composition_ok', 'veto_cleared', 'veto_manual', 'score_coverage_pct', 'clean', 'note'],
  properties: {
    verdict: { type: 'string', description: '可直接提交/补料后可提交/仅可作初稿' },
    coverage_pct: { type: 'number' }, composition_ok: { type: 'boolean' },
    veto_cleared: { type: 'number', description: '已规避的废标条款数' },
    veto_manual: { type: 'number', description: '需人工处理的废标条款数' },
    score_coverage_pct: { type: 'number' }, clean: { type: 'boolean', description: '零脚手架且无泄露无编造' },
    note: { type: 'string' },
  },
}
const verify = await agent(
  `你是投标文件质检员(客观核对,不奉承)。对照招标 ${TENDER}，核对交付稿 ${deliveryFiles.join('、')}，` +
  `并读 评分点响应矩阵.md、废标风险清单.md、投标文件组成.md。核对:①覆盖率%(列真漏的)②组成完整性③废标风险逐条已规避?(把清单"状态"改为已规避/未规避/需人工)④评分点覆盖率%(【高】项是否重点展开)⑤纯净度(无空引用/零脚手架/未编造/无泄露)。\n` +
  `写 ${OUT}/投标文件自检报告.md：结论(可直接提交/补料后可提交/仅可作初稿+理由)+检查项表+高风险缺失项+需人工补充确认清单(投标人名称/产品存疑项/报价/资质/案例/签章)。返回结构化结果。`,
  { label: '10验证自检', phase: '验证自检', schema: VERIFY_SCHEMA }
)
log(`自检：${verify ? verify.verdict : '?'}｜覆盖${verify ? verify.coverage_pct : 0}%｜评分点覆盖${verify ? verify.score_coverage_pct : 0}%｜废标已规避${verify ? verify.veto_cleared : 0}/需人工${verify ? verify.veto_manual : 0}`)

// ---------- 阶段7：出 Word + 格式自检门禁（需 args.skillDir 且未显式关闭） ----------
let word = null
if (SKILL_DIR && A.export !== false) {
  phase('出Word')
  const WORD_SCHEMA = { type: 'object', additionalProperties: false,
    required: ['docx_files', 'format_pass', 'issues_fixed', 'unresolved'],
    properties: {
      docx_files: { type: 'array', items: { type: 'string' }, description: '导出的 docx 绝对路径' },
      format_pass: { type: 'boolean', description: '格式自检最终是否全部通过' },
      issues_fixed: { type: 'number', description: '自检发现并已修复后重导的不符项数' },
      unresolved: { type: 'array', items: { type: 'string' }, description: '仍未过的不符项(应为空)' } } }
  word = await agent(
    `你是出Word执行员。交付稿：${deliveryFiles.join('、')}；格式spec：${OUT}/word_format_spec.json(可能不存在=用默认格式)。\n` +
    `⛔ 铁律（"格式不像国内标书"的头号来源就是违反这条）：出 Word **只准**用下面两个脚本，` +
    `**严禁**用 pandoc / python-docx 自写代码 / markdown 转换器 / 在线服务等任何其他方式导出——那些产物没有标书封面/目录/页码分节/字体规范，必然不合规。` +
    `python-docx 装不上（pip install python-docx 失败）→ **不出 Word**，如实报告并把下面的命令原样交给用户在本机跑。\n` +
    `对每份交付稿执行：\n` +
    `1) python3 ${SKILL_DIR}/references/build_tender_docx.py <交付稿.md> <同名.docx> --title "<项目名称,从招标文件或交付稿书名取>" ` +
    `--subtitle "<册名,如 投标文件（技术标）>" --images-dir ${MAT}，存在 word_format_spec.json 则加 --format-spec ${OUT}/word_format_spec.json；\n` +
    `2) python3 ${SKILL_DIR}/references/check_docx_format.py <同名.docx> --title "<项目名称>" 同样带 --format-spec —— 这是格式门禁：` +
    `退出码非0则读它的输出与 *_格式自检报告.md，判断是 spec 写错(如字号/字段拼写/臆造的字段值)还是导出问题；` +
    `若自检器提示"与国内标书惯例不符"，核对招标原文——招标没这么要求就把 spec 里对应字段删掉(用默认值)，修正后重新导出+复检，直到通过或确认为环境限制。\n` +
    `导出时"图片打标未命中素材"的提示不算门禁失败(已留占位)，列入需人工；"打标未解析"则要检查 tender_images.py 与 --images-dir。\n` +
    `报价册如含报价表可提示另出xlsx(不阻塞)。返回结构化结果。`,
    { label: '11出Word', phase: '出Word', schema: WORD_SCHEMA, effort: 'low' })   // 跑命令+按输出修参数,低推理档
  if (word) log(`出Word：${(word.docx_files || []).length} 份｜格式自检${word.format_pass ? '通过✅' : '未过❌'}${word.issues_fixed ? `｜修复${word.issues_fixed}项后过检` : ''}${(word.unresolved || []).length ? `｜遗留:${word.unresolved.join(';')}` : ''}`)
} else if (!SKILL_DIR) {
  log('未传 args.skillDir，跳过出Word阶段——请按 SKILL.md【出 Word】用 build_tender_docx.py 手动导出并跑 check_docx_format.py 格式自检（禁止用其他工具导出）')
}

return {
  domain: plan ? plan.domain : null,
  total_points: plan ? plan.total_points : 0,
  agents_used: 1 + (ingest ? 1 : 0) + 3 + 1 + chapters.length + 1 + thin.length + 1 + 1 + (tag ? 1 : 0) + 1 + (word ? 1 : 0),  // 预检(+入库)+前置×3+拆解+撰写×N+字数验收+扩写×M+应答+汇总(+配图)+验证(+出Word)
  volumes, delivery_files: deliveryFiles,
  format_spec: OUT + '/word_format_spec.json',
  素材: { dir: MAT, found: MAT_OK, files: (pre && pre.materials_found) || [], image_index: HAS_IMG_INDEX, 图片入库: ingest },
  撰写验收: { 每章下限: MIN_WORDS, 核验字数: realWords, 扩写章数: thin.length, fast模式: FAST },
  chapters: ok.map((c, i) => ({ no: i + 1, chapter: c.chapter, words: c.words, mermaid: c.mermaid, clean: c.inbody_internal_id === 0 && c.real_name_leak === 0 })),
  评分废标: score ? { 评分点: score.score_items, 总分: score.total_score, 高优: score.high_priority, 废标条款: score.veto_items } : null,
  应答偏离表: resp ? { 共: resp.total, 满足: resp.met, 部分满足: resp.partial, 不满足: resp.unmet, 商务偏离: resp.biz_deviations, 素材已用: resp.materials_used } : null,
  自检: verify || null,
  出Word: word,   // null=未执行(没传skillDir或export:false)
  next: word && word.format_pass
    ? 'docx 已导出且格式自检通过；招标给了docx模板的格式件用 fill_tender_template.py 套版补齐。'
    : '用 build_tender_docx.py --format-spec word_format_spec.json 对每册导出 Word，再用 check_docx_format.py 做格式自检(门禁)；招标给了docx模板则用 fill_tender_template.py 套版。禁止用其他工具导出。',
}
