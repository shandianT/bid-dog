#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
真实 Word 模板套版：招标书给了投标文件格式模板(docx)时，不重新生成，而是**保留模板样式填充内容**。
用法：
  1) 占位替换（授权书/投标函/承诺函等格式件）：
     python3 fill_tender_template.py 招标方模板.docx 输出.docx --data 填充数据.json
     填充数据.json 形如 {"投标人名称":"XX公司","项目名称":"...","法定代表人":"..."}
     会替换模板里的 {{投标人名称}}、〔投标人名称〕、（投标人名称）三种占位写法——跨 run 精确替换：
     替换文本落在占位符起始的 run（继承其格式，填在下划线空位上仍是下划线），段内其他文字格式零改动。
     模板里没占位符、只有空格/下划线的：先人工在模板里把空位改成 {{字段名}} 再跑本脚本。
  2) 内容追加（把生成的方案 md 用模板自带样式接在模板后面）：
     python3 fill_tender_template.py 招标方模板.docx 输出.docx --append 投标技术方案.md
  3) 图片打标自动插入（--images-dir 素材目录，或自动找 <模板同目录>/素材）：
     模板/追加内容里的 {{图:图片ID}}、〔图:ID〕、![图注](路径) 自动替换为素材库真图——
     同样是跨 run 原位插入：图片落在占位符位置，段内其他文字与格式不动；
     正文段、表格单元格（"在此插入营业执照"类格式件槽位改成 {{图:营业执照}} 即可批量塞图）、页眉logo槽均支持；
     图片ID 到 素材目录/图片索引.md(json) 查文件；缺图不报错→保留占位符并在结束时提醒人工插入。
     --append 内容里同一图片多处打标默认去重（首插编号，后续"（见图N）"引用；--repeat-images 关闭）；
     模板自带槽位不去重（模板作者要求几处就插几处）。语法解析见同目录 tender_images.py（需一并拷走）。
  各方式可同时使用。页眉页脚里的占位符同样会替换；未填占位符扫描也覆盖页眉页脚。
依赖：pip install python-docx
"""
import re, json, argparse, os, sys
from copy import deepcopy
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from tender_images import ImageLibrary, has_image_marker, split_image_markers, fit_image, MARKER_RE, MD_IMG_RE
except ImportError:  # tender_images.py 未随脚本拷贝：图片打标功能自动关闭，其余功能不受影响
    ImageLibrary = None
    has_image_marker = lambda t: False
    split_image_markers = lambda t: [('text', t, None)]
    fit_image = lambda p, w, h: (w, None)
    MARKER_RE = MD_IMG_RE = None

def _patterns(key):
    return ['{{%s}}' % key, '〔%s〕' % key, '（%s）' % key]

def _replace_span(par, pat, val):
    """跨 run 精确替换一处占位符：替换文本落在占位符起始的那个 run（继承其格式，
    如下划线空位、加粗），占位符覆盖到的其余 run 只删被覆盖的部分——段内其他文字的格式原样保留。"""
    runs = par.runs
    full = ''.join(r.text for r in runs)
    idx = full.find(pat)
    if idx < 0: return False
    end = idx + len(pat)
    pos = 0; inserted = False
    for r in runs:
        s, e = pos, pos + len(r.text); pos = e
        if e <= idx or s >= end: continue
        pre = r.text[:max(0, idx - s)]
        post = r.text[max(0, min(len(r.text), end - s)):]
        if not inserted: r.text = pre + val + post; inserted = True
        else: r.text = pre + post
    return True

def replace_in_paragraph(par, mapping):
    """把段落里的全部占位符逐个替换，返回替换处数"""
    n = 0
    while True:
        hit = False
        for key, val in mapping.items():
            for pat in _patterns(key):
                if _replace_span(par, pat, str(val)): n += 1; hit = True
        if not hit: return n

def walk_tables(tables, fn):
    n = 0
    for t in tables:
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs: n += fn(p)
                n += walk_tables(cell.tables, fn)
    return n

def fill_placeholders(doc, mapping):
    n = 0
    fn = lambda p: replace_in_paragraph(p, mapping)
    for p in doc.paragraphs: n += fn(p)
    n += walk_tables(doc.tables, fn)
    for sec in doc.sections:  # 页眉页脚
        for part in (sec.header, sec.footer):
            for p in part.paragraphs: n += fn(p)
            n += walk_tables(part.tables, fn)
    return n

# ---------------- 图片打标：跨 run 原位插入 ----------------
def _page_box_cm(doc):
    """版心可用宽高(cm)，正文插图的最大框"""
    try:
        sec = doc.sections[0]
        w = (sec.page_width - sec.left_margin - sec.right_margin).cm - 0.3
        h = (sec.page_height - sec.top_margin - sec.bottom_margin).cm - 3.0
        return max(w, 5.0), max(h, 5.0)
    except Exception:
        return 14.6, 20.0

def _all_markers(par):
    """段落全文里的图片打标 [(start, end, ref, 图注), ...] 按位置排序"""
    if MARKER_RE is None: return []
    full = ''.join(r.text for r in par.runs)
    hits = [(m.start(), m.end(), m.group(1).strip(), (m.group(2) or '').strip() or None)
            for m in MARKER_RE.finditer(full)]
    hits += [(m.start(), m.end(), m.group(2).strip(), (m.group(1) or '').strip() or None)
             for m in MD_IMG_RE.finditer(full)]
    return sorted(hits)

def _replace_text_span(par, s, e, val):
    """按位置替换 [s,e) 为文本（承载 run 继承原格式），其余跨越 run 只删被覆盖部分"""
    pos = 0; ins = False
    for r in par.runs:
        s0, e0 = pos, pos + len(r.text); pos = e0
        if e0 <= s or s0 >= e: continue
        a, b = max(0, s - s0), min(len(r.text), e - s0)
        if not ins: r.text = r.text[:a] + val + r.text[b:]; ins = True
        else: r.text = r.text[:a] + r.text[b:]

def _cut_span_for_insert(par, s, e):
    """抠掉 [s,e)：首个跨越 run 截到占位符前（作插入锚点），其后残余文本以 (tail_text, tail_rpr) 返回，
    其余跨越 run 只删被覆盖部分。返回 (carrier_run|None, tail_text, tail_rpr)"""
    pos = 0; carrier = None; tail_text = ''; tail_rpr = None
    for r in par.runs:
        s0, e0 = pos, pos + len(r.text); pos = e0
        if e0 <= s or s0 >= e: continue
        a, b = max(0, s - s0), min(len(r.text), e - s0)
        if carrier is None:
            carrier = r
            tail_text = r.text[b:]
            tail_rpr = deepcopy(r._r.rPr) if r._r.rPr is not None else None
            r.text = r.text[:a]
        else:
            r.text = r.text[:a] + r.text[b:]
    return carrier, tail_text, tail_rpr

def _insert_runs_after(carrier, runs):
    anchor = carrier._r
    for run in runs:
        anchor.addnext(run._r); anchor = run._r

def _replace_images_in_paragraph(par, imglib, max_w, max_h, dedup_fig=None):
    """段内图片打标→原位插图（跨 run 精确：段内其他文字与格式不动）。
    dedup_fig=图号计数器[list]时启用同图去重（已插过→"（见图N）"，首插图后补"图N"编号）；
    模板自带槽位调用时不传 dedup_fig（不去重不编号）。未命中素材的打标原样保留→进"未填占位符"提醒。"""
    n = 0; skipped = 0; guard = 0
    while guard < 60:
        guard += 1
        hits = _all_markers(par)
        if len(hits) <= skipped: break
        s, e, ref, _cap = hits[skipped]
        path, _defcap = imglib.resolve(ref)
        if not path:
            if ref not in imglib.missing: imglib.missing.append(ref)
            skipped += 1; continue
        if dedup_fig is not None and path in imglib.fig_of:
            _replace_text_span(par, s, e, '（见图%d）' % imglib.fig_of[path]); continue
        carrier, tail_text, tail_rpr = _cut_span_for_insert(par, s, e)
        if carrier is None: break
        w, h = fit_image(path, max_w, max_h)
        new_runs = []
        img_run = par.add_run()
        try:
            img_run.add_picture(path, width=Cm(w), height=Cm(h)) if h else img_run.add_picture(path, width=Cm(w))
            imglib.inserted.append((ref, path)); n += 1
            new_runs.append(img_run)
            if dedup_fig is not None:
                dedup_fig[0] += 1; imglib.fig_of.setdefault(path, dedup_fig[0])
                new_runs.append(par.add_run(' 图%d' % imglib.fig_of[path]))
        except Exception:
            img_run.text = '{{图:%s}}' % ref   # 图片文件损坏：留占位符
            if ref not in imglib.missing: imglib.missing.append(ref)
            new_runs.append(img_run); skipped += 1
        if tail_text:
            tr = par.add_run(tail_text)
            if tail_rpr is not None: tr._r.insert(0, deepcopy(tail_rpr))
            new_runs.append(tr)
        _insert_runs_after(carrier, new_runs)
    return n

def insert_marked_images(doc, imglib):
    """全文档图片打标替换（模板自带槽位，不去重）：正文段(版心适配) / 表格单元格(格宽适配) / 页眉页脚(限高logo)"""
    max_w, max_h = _page_box_cm(doc)
    n = 0
    def walk(tables, cw_cap, ch):
        m = 0
        for t in tables:
            for row in t.rows:
                for cell in row.cells:
                    try: cw = cell.width.cm - 0.4 if cell.width else 7.5
                    except Exception: cw = 7.5
                    cw = max(2.0, min(cw, cw_cap))
                    for p in cell.paragraphs: m += _replace_images_in_paragraph(p, imglib, cw, ch)
                    m += walk(cell.tables, cw_cap, ch)
        return m
    for p in doc.paragraphs: n += _replace_images_in_paragraph(p, imglib, max_w, max_h)
    n += walk(doc.tables, max_w, 10.0)
    for sec in doc.sections:
        for part in (sec.header, sec.footer):
            for p in part.paragraphs: n += _replace_images_in_paragraph(p, imglib, max_w, 2.5)
            n += walk(part.tables, max_w, 2.5)
    return n

def find_unfilled(doc):
    """扫描仍残留的占位符（含页眉页脚），提醒人工补料"""
    left = set()
    pat = re.compile(r'(\{\{[^}]{1,30}\}\}|〔[^〕]{1,30}〕)')
    def scan(p):
        for m in pat.findall(p.text): left.add(m)
        return 0
    for p in doc.paragraphs: scan(p)
    walk_tables(doc.tables, scan)
    for sec in doc.sections:
        for part in (sec.header, sec.footer):
            for p in part.paragraphs: scan(p)
            walk_tables(part.tables, scan)
    return sorted(left)

def style_name(doc, *candidates):
    names = {s.name for s in doc.styles}
    for c in candidates:
        if c in names: return c
    return None

def append_markdown(doc, md_path, imglib=None, dedup=True):
    """把 md 内容用模板自带样式追加到文档末尾（标题→模板的标题1/2/3样式，正文→Normal，表格→模板默认表样式）"""
    md = open(md_path, encoding='utf-8').read().split('\n')
    h = {i: style_name(doc, 'Heading %d' % i, '标题 %d' % i, '标题%d' % i) for i in (1, 2, 3)}
    tbl_style = style_name(doc, 'Table Grid', '网格型')
    max_w, max_h = _page_box_cm(doc)
    fig = [0]
    doc.add_page_break()
    i = 0; first_h1_is_title = True
    while i < len(md):
        ln = md[i]
        if ln.strip() == '': i += 1; continue
        if ln.startswith('```'):  # 代码块/mermaid：模板套版场景降级为图注
            lang = ln.strip('`').strip(); i += 1
            while i < len(md) and not md[i].startswith('```'): i += 1
            i += 1
            if lang.lower() == 'mermaid': doc.add_paragraph('（流程图：见随附图纸）')
            continue
        if ln.startswith('|') and i + 1 < len(md) and md[i + 1].strip().startswith('|'):
            tb = []
            while i < len(md) and md[i].strip().startswith('|'): tb.append(md[i]); i += 1
            rows = [[c.strip() for c in r.strip().strip('|').split('|')] for r in tb
                    if set(r.replace('|', '').replace('-', '').replace(':', '').strip()) != set()]
            if rows:
                ncols = max(len(r) for r in rows)
                t = doc.add_table(rows=len(rows), cols=ncols)
                if tbl_style: t.style = tbl_style
                # 固定列宽防"一列一个字"竖排:按列内容量分宽、窄列保底、宽表自动缩字号、表头跨页重复
                sec = doc.sections[-1]
                avail = (sec.page_width.cm - sec.left_margin.cm - sec.right_margin.cm) or 15.0
                MINW = 1.1
                dlen = lambda s: sum(1.0 if ord(ch) > 0x2E7F else 0.55 for ch in str(s)) or 1.0
                need = [min(max(max((dlen(r[ci]) for r in rows if ci < len(r) and str(r[ci]).strip()), default=2.0), 2.0), 26.0)
                        for ci in range(ncols)]
                ws = [avail * x / sum(need) for x in need]
                for _ in range(ncols):
                    lack = sum(MINW - x for x in ws if x < MINW)
                    rich = [i for i, x in enumerate(ws) if x > MINW + 1e-6]
                    if lack <= 1e-6 or not rich: break
                    pool = sum(ws[i] - MINW for i in rich)
                    for i in rich: ws[i] -= lack * (ws[i] - MINW) / pool
                    ws = [max(x, MINW) for x in ws]
                t.autofit = False
                tblPr = t._tbl.tblPr
                lay = OxmlElement('w:tblLayout'); lay.set(qn('w:type'), 'fixed'); tblPr.append(lay)
                grid = t._tbl.find(qn('w:tblGrid'))
                if grid is not None:
                    for gc, wcm in zip(grid.findall(qn('w:gridCol')), ws): gc.set(qn('w:w'), str(int(round(wcm * 567))))
                trPr = t.rows[0]._tr.get_or_add_trPr()
                if trPr.find(qn('w:tblHeader')) is None: trPr.append(OxmlElement('w:tblHeader'))
                fsz = 8.0 if ncols >= 12 else (9.0 if ncols >= 8 else 10.5)
                for ri, row in enumerate(rows):
                    for ci, cell in enumerate(row):
                        tc = t.cell(ri, ci); tc.width = Cm(ws[ci])
                        para = tc.paragraphs[0]
                        r = para.add_run(cell); r.bold = (ri == 0); r.font.size = Pt(fsz)
                        if imglib and has_image_marker(cell):
                            _replace_images_in_paragraph(para, imglib, 7.5, 10.0, dedup_fig=fig if dedup else None)
            continue
        m = re.match(r'^(#{1,6})\s', ln)
        if m:
            lvl = min(len(m.group(1)), 3)
            if lvl == 1 and first_h1_is_title: first_h1_is_title = False; i += 1; continue
            text = re.sub(r'^#+\s*', '', ln).strip()
            st = h.get(lvl)
            p = doc.add_paragraph(text, style=st) if st else doc.add_paragraph(text)
            if not st: p.runs and setattr(p.runs[0], 'bold', True)
            i += 1; continue
        if imglib and has_image_marker(ln):  # 图片打标行：插图居中 + "图N 图注"，同图重复→"（见图N）"，缺图留占位
            for kind, ref, cap in split_image_markers(re.sub(r'^\s*[-*]\s+|^>\s*', '', ln)):
                if kind == 'text':
                    if ref.strip(): doc.add_paragraph(ref.strip())
                    continue
                path, defcap = imglib.resolve(ref)
                cap = cap or defcap
                if path and dedup and path in imglib.fig_of:
                    p = doc.add_paragraph('（见图%d%s）' % (imglib.fig_of[path], ' ' + cap if cap else ''))
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    continue
                fig[0] += 1
                done = False
                if path:
                    w, hh = fit_image(path, max_w, max_h)
                    try:
                        p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                        run = p.add_run()
                        run.add_picture(path, width=Cm(w), height=Cm(hh)) if hh else run.add_picture(path, width=Cm(w))
                        imglib.inserted.append((ref, path)); imglib.fig_of.setdefault(path, fig[0]); done = True
                        cp = doc.add_paragraph('图%d %s' % (fig[0], cap) if cap else '图%d' % fig[0])
                        cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    except Exception: done = False
                if not done:
                    imglib.missing.append(ref)
                    p = doc.add_paragraph('〔图%d：%s —— 图片素材缺失，需人工插入〕' % (fig[0], cap or ref))
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            i += 1; continue
        text = ln
        if re.match(r'^\s*[-*]\s+', ln): text = '· ' + re.sub(r'^\s*[-*]\s+', '', ln)
        elif ln.startswith('>'): text = ln.lstrip('> ').strip()
        elif re.match(r'^---+$', ln.strip()): i += 1; continue
        p = doc.add_paragraph()
        for seg in re.split(r'(\*\*.+?\*\*)', text):
            if not seg: continue
            b = seg.startswith('**') and seg.endswith('**')
            r = p.add_run(seg[2:-2] if b else seg); r.bold = b
        i += 1

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('template'); ap.add_argument('out')
    ap.add_argument('--data', default=None, help='占位替换数据 JSON')
    ap.add_argument('--append', default=None, help='追加的 markdown 内容文件')
    ap.add_argument('--images-dir', default=None, help='图片素材目录(含 图片索引.md/json)；默认自动找模板/md 同目录的 素材/')
    ap.add_argument('--repeat-images', action='store_true',
                    help='--append 内容里同一图片多处打标时每处都插整图（默认去重改写为"（见图N）"；模板自带槽位永远原样插入）')
    a = ap.parse_args()
    doc = Document(a.template)
    fallback = [os.path.dirname(os.path.abspath(a.template))]
    if a.append: fallback.append(os.path.dirname(os.path.abspath(a.append)))
    imglib = ImageLibrary(a.images_dir, fallback) if ImageLibrary else None
    n = 0
    if a.data:
        mapping = json.load(open(a.data, encoding='utf-8'))
        n = fill_placeholders(doc, mapping)
    if imglib: insert_marked_images(doc, imglib)   # 模板自带的 {{图:ID}} 槽位（正文/表格/页眉），不参与去重
    if a.append: append_markdown(doc, a.append, imglib, dedup=not a.repeat_images)
    doc.save(a.out)
    left = find_unfilled(Document(a.out))
    print('模板套版完成：%s（替换 %d 处占位符，原格式保留）' % (a.out, n))
    if imglib:
        for line in imglib.report(): print(line)
    if left: print('⚠️ 仍有未填占位符，需人工补料：' + '、'.join(left[:20]))

if __name__ == '__main__':
    main()
