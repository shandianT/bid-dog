#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
成品质检门禁(确定性脚本,不靠模型)——出 Word 之前的最后一道闸,也是自动修复器。

管四件事(每件都是现场真实翻过车的):
  1) 图片落位:以《图片索引》的「落位锚点/关键词」为准——模型打的 {{图:ID}} 只当建议。
     放错章节自动搬正、索引里有锚点却漏打的自动补插、伪造 ID 剔除为〔配图待人工〕;产《配图清单》。
  2) 章节字数:按章统计正文字数,低于门槛判黄/红(字数是"内容变薄"的最早信号)。
  3) 内容健康:正文逐字打散、同段重复灌注 → 检测并可自动修复(与 doc_quality 同口径)。
  4) 应答覆盖:偏离表条目数 vs 评分点条目数,覆盖率过低判黄/红。

用法:
  python3 quality_gate.py <交付稿.md> --materials <素材库> [--fix] [--min-chapter 3500]
      [--score 评分点响应矩阵.md] [--deviation 技术应答偏离表.md] [--deviation 商务偏离表.md]
      [--report 成品质检报告.md]
  --fix:原地修复(先备份为 <原名>.bak.md):重复折叠+碎片合并+图片搬正/补插/剔除。
退出码:0=通过 1=有黄牌(建议处理) 2=有红牌(不修复不该交付)。
API:audit(md, materials=..., ...) / fix(md, ...) 供引擎/其他脚本 import 调用。
"""
import os, re, sys, json, collections

IMG_EXTS = ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tif', '.tiff', '.emf', '.wmf')
MARKER_RE = re.compile(
    r'(?:\{\{|〔)\s*(?:图片?|img|image)\s*[:：]\s*([^|｜}〕\n]+?)\s*(?:[|｜]\s*([^}〕\n]+?)\s*)?(?:\}\}|〕)',
    re.IGNORECASE)
SKIP_CHAPTER = re.compile(r'(目录|封面|扉页|声明|偏离|清单|报告|附录|附件|矩阵|说明|承诺|函$)')
SHORT, REPEAT_LIMIT, SHORT_RATIO = 4, 8, 0.15   # 与 doc_quality 同口径

# ---------------- 图片索引(含扩展列:关键词/落位锚点) ----------------

def load_index(materials):
    """图片索引 → [{id,file(绝对路径),caption,keywords,anchor}];md/json 都认,json 认 list 与 dict 两种形态"""
    dirs = []
    for d in ([materials] if materials else []):
        d = os.path.abspath(d)
        for c in (d, os.path.join(d, '素材'), os.path.join(d, '图片'), os.path.join(d, '素材', '图片')):
            if os.path.isdir(c) and c not in dirs: dirs.append(c)
    entries, index_path = [], None
    for d in dirs:
        for name in ('图片索引.json', '图片索引.md', 'image_index.json', 'image_index.md'):
            p = os.path.join(d, name)
            if not os.path.isfile(p): continue
            try:
                if p.endswith('.json'):
                    data = json.load(open(p, encoding='utf-8'))
                    items = data if isinstance(data, list) else \
                        [{'id': k, **(v if isinstance(v, dict) else {'file': v})} for k, v in data.items()]
                    for e in items:
                        if not e.get('id') or not e.get('file'): continue
                        entries.append({'id': str(e['id']).strip(),
                                        'file': os.path.normpath(os.path.join(d, str(e.get('file')))),
                                        'caption': e.get('caption') or e.get('图注') or '',
                                        'keywords': str(e.get('keywords') or e.get('关键词') or ''),
                                        'anchor': str(e.get('anchor') or e.get('落位锚点') or '')})
                else:
                    rows = [[c.strip() for c in ln.strip().strip('|').split('|')]
                            for ln in open(p, encoding='utf-8')
                            if ln.strip().startswith('|') and set(ln.replace('|', '').replace('-', '').replace(':', '').strip())]
                    if not rows: continue
                    head = [h.lower() for h in rows[0]]
                    def col(*keys):
                        for i, h in enumerate(head):
                            if any(k in h for k in keys): return i
                        return None
                    ci, cf = col('图片id', 'id') or 0, col('文件', '路径', 'file')
                    cf = 1 if cf is None else cf
                    cc, ck, ca = col('图注', '标题', 'caption'), col('关键词', '场景', 'keyword'), col('锚点', 'anchor')
                    for r in rows[1:]:
                        if len(r) <= max(ci, cf) or not r[ci] or r[ci].startswith('（'): continue
                        g = lambda i: (r[i] if i is not None and len(r) > i else '') or ''
                        entries.append({'id': r[ci], 'file': os.path.normpath(os.path.join(d, r[cf])),
                                        'caption': g(cc), 'keywords': g(ck), 'anchor': g(ca)})
                if entries: return entries, p, dirs
            except Exception:
                continue
    return entries, index_path, dirs

def resolvable(ref, dirs):
    """打标引用能不能落到真实文件(索引缺席时的宽容口径,与 tender_images 一致方向)"""
    cands = [ref] if os.path.splitext(ref)[1].lower() in IMG_EXTS else [ref + e for e in IMG_EXTS]
    for d in dirs:
        for c in cands:
            if os.path.isfile(os.path.join(d, c)): return True
    return False

# ---------------- 文档结构 ----------------

def parse_doc(text):
    lines = text.splitlines()
    heads = [(i, len(m.group(1)), m.group(2).strip())
             for i, ln in enumerate(lines)
             if (m := re.match(r'^(#{1,4})\s+(.+)', ln))]
    return lines, heads

def section_bounds(heads, lines_n, idx):
    """第 idx 个标题的管辖区间 [start, end)(到下一个同级或更高级标题)"""
    i, lv, _ = heads[idx]
    end = lines_n
    for j in range(idx + 1, len(heads)):
        if heads[j][1] <= lv: end = heads[j][0]; break
    return i, end

def owner_head(heads, line_i):
    """行属于哪个标题(最近的前置标题的序号);没有 → -1"""
    own = -1
    for k, (i, lv, t) in enumerate(heads):
        if i <= line_i: own = k
        else: break
    return own

def find_anchor(anchor, keywords, lines, heads):
    """锚点 → (目标行号, 方式);优先标题包含,其次正文段包含,再退关键词。找不到 → (None, '')"""
    cands = [a.strip() for a in re.split(r'[;；|/]', anchor or '') if a.strip()]
    cands += [k.strip() for k in re.split(r'[、,，;；/\s]+', keywords or '') if len(k.strip()) >= 2][:6]
    for a in cands:
        a2 = re.sub(r'^第[一二三四五六七八九十\d]+章[·\s:：-]*', '', a)
        for k, (i, lv, t) in enumerate(heads):
            if a in t or (a2 and a2 in t): return ('head', k), 'anchor 命中标题「%s」' % t
    for a in cands:
        for i, ln in enumerate(lines):
            if len(a) >= 2 and a in ln and not ln.startswith('#') and not MARKER_RE.search(ln):
                return ('line', i), 'anchor 命中正文段(第 %d 行)' % (i + 1)
    return None, ''

def insert_point(target, lines, heads):
    """图片插入行号:标题命中 → 标题后的第一个正文段之后;正文命中 → 该段之后"""
    kind, v = target
    if kind == 'line': return v + 1
    hi, end = section_bounds(heads, len(lines), v)
    j = hi + 1
    while j < end and not lines[j].strip(): j += 1
    while j < end and lines[j].strip() and not lines[j].startswith('#'): j += 1   # 越过第一段
    return min(j, end)

# ---------------- 内容健康(与 doc_quality 同口径,独立实现保证脚本可单拷) ----------------

def health_detect(text):
    ls = [l.strip() for l in text.splitlines()]
    body = [l for l in ls if l and not l.startswith(('#', '|', '>', '-', '*', '```', '!'))]
    if not body: return []
    short = [l for l in body if len(l) < SHORT]
    cnt = collections.Counter(l for l in body if len(l) >= 12)
    top, times = (cnt.most_common(1)[0] if cnt else ('', 0))
    issues = []
    if len(short) / len(body) > SHORT_RATIO:
        issues.append(('red', '正文被逐字打散(%d/%d 段只有 1~3 个字)' % (len(short), len(body))))
    if times > REPEAT_LIMIT:
        issues.append(('red', '同一段落重复 %d 次:%s…' % (times, top[:36])))
    return issues

def health_repair(text):
    out, buf = [], []
    cnt = collections.Counter(l.strip() for l in text.splitlines() if len(l.strip()) >= 12)
    dup = {t for t, n in cnt.items() if n > REPEAT_LIMIT}
    seen = set()
    def flush():
        if buf: out.append(''.join(buf)); buf.clear()
    for raw in text.splitlines():
        s = raw.strip()
        if not s:
            if buf: continue
            out.append(''); continue
        if s.startswith(('#', '|', '>', '-', '*', '```', '!')) or re.match(r'^\d+[.、]', s):
            flush(); out.append(raw); continue
        if s in dup:
            key = (len([o for o in out if o.startswith('#')]), s)
            if key in seen: continue
            seen.add(key); flush(); out.append(s); continue
        if len(s) < SHORT: buf.append(s); continue
        flush(); out.append(raw)
    flush()
    res, blank = [], 0
    for l in out:
        blank = blank + 1 if l == '' else 0
        if blank > 1: continue
        res.append(l)
    return '\n'.join(res).strip() + '\n'

# ---------------- 字数 ----------------

def chapter_stats(lines, heads):
    lv = 1 if sum(1 for _, l, _ in heads if l == 1) >= 2 else 2
    chaps = []
    for k, (i, l, t) in enumerate(heads):
        if l != lv or SKIP_CHAPTER.search(t): continue
        s, e = section_bounds(heads, len(lines), k)
        body = '\n'.join(ln for ln in lines[s + 1:e] if not ln.startswith('|'))
        body = MARKER_RE.sub('', body)
        n = len(re.findall(r'[\w一-鿿]', body))
        chaps.append({'title': t, 'chars': n})
    return chaps

def table_rows(path):
    if not path or not os.path.isfile(path): return None
    n = 0
    for ln in open(path, encoding='utf-8', errors='ignore'):
        s = ln.strip()
        if s.startswith('|') and not set(s.replace('|', '').replace('-', '').replace(':', '').strip()) == set():
            n += 1
    return max(0, n - 1)   # 去掉表头

# ---------------- 主审计 ----------------

def audit(md_path, materials=None, min_chapter=3500, score=None, deviations=None, _for_fix=False):
    text = open(md_path, encoding='utf-8', errors='ignore').read()
    entries, index_path, dirs = load_index(materials)
    byid = {e['id']: e for e in entries}
    lines, heads = parse_doc(text)
    items, images, plan = [], [], []   # items: (level,text) ; plan: 修复动作
    # 1) 打标清点
    marks = []   # (line_i, id)
    for i, ln in enumerate(lines):
        for m in MARKER_RE.finditer(ln):
            marks.append((i, m.group(1).strip()))
    mark_ids = collections.Counter(x[1] for x in marks)
    for i, rid in marks:
        if rid not in byid and not resolvable(rid, dirs):
            items.append(('red', '图片打标「%s」在索引里不存在,也不是素材里的文件(疑似模型编造)' % rid))
            plan.append({'act': 'strip', 'id': rid, 'line': i})
    # 2) 逐图核对锚点
    for e in entries:
        rid = e['id']
        target, why = (find_anchor(e['anchor'], e['keywords'], lines, heads) if (e['anchor'] or e['keywords']) else (None, ''))
        pos = [i for i, x in marks if x == rid]
        if not pos:
            if target:
                items.append(('yellow', '素材图「%s」有落位依据但全文未打标,将自动补插(%s)' % (rid, why)))
                plan.append({'act': 'insert', 'id': rid, 'target': target})
                images.append({'id': rid, 'where': why, 'action': '补插'})
            else:
                images.append({'id': rid, 'where': '—', 'action': '未引用(无锚点,留人工)'})
            continue
        if not target:
            images.append({'id': rid, 'where': '维持模型位置(索引无锚点)', 'action': '保留'})
            continue
        # 有锚点:检查现有打标是否落在目标章节内
        tk = target[1] if target[0] == 'head' else owner_head(heads, target[1])
        ok_here = []
        for i in pos:
            oh = owner_head(heads, i)
            same = (oh == tk) or (tk >= 0 and oh >= 0 and
                                  section_bounds(heads, len(lines), tk)[0] <= i < section_bounds(heads, len(lines), tk)[1])
            ok_here.append(same)
        if any(ok_here):
            # 至少有一处落在正确章节:保留;同 ID 的多余打标交给导出器去重(见图N),不在这里动
            images.append({'id': rid, 'where': why, 'action': '保留(位置正确)'})
        else:
            items.append(('yellow', '素材图「%s」打标位置与锚点不符,将自动搬正(%s)' % (rid, why)))
            for i in pos: plan.append({'act': 'strip', 'id': rid, 'line': i})
            plan.append({'act': 'insert', 'id': rid, 'target': target})
            images.append({'id': rid, 'where': why, 'action': '搬正'})
    # 3) 内容健康
    for lv, t in health_detect(text): items.append((lv, t))
    # 4) 字数
    chaps = chapter_stats(lines, heads)
    for c in chaps:
        if c['chars'] < 2000: items.append(('red', '章节「%s」仅 %d 字(<2000,内容明显偏薄)' % (c['title'], c['chars'])))
        elif c['chars'] < min_chapter: items.append(('yellow', '章节「%s」%d 字(<%d,建议扩写)' % (c['title'], c['chars'], min_chapter)))
    # 5) 覆盖率
    cov = None
    srows = table_rows(score)
    drows = sum(filter(None, (table_rows(d) for d in (deviations or []))))
    if srows and srows >= 5:
        ratio = (drows or 0) / srows
        cov = {'score_rows': srows, 'deviation_rows': drows or 0, 'ratio': round(ratio, 2)}
        if ratio < 0.5: items.append(('red', '应答覆盖率仅 %d%%(偏离表 %d 条 / 评分点 %d 条)' % (ratio * 100, drows or 0, srows)))
        elif ratio < 0.8: items.append(('yellow', '应答覆盖率 %d%%(偏离表 %d 条 / 评分点 %d 条,建议补齐)' % (ratio * 100, drows or 0, srows)))
    level = 'red' if any(l == 'red' for l, _ in items) else ('yellow' if items else 'green')
    return {'level': level, 'items': items, 'chapters': chaps, 'images': images, 'coverage': cov,
            'plan': plan, 'index_path': index_path, 'materials': materials,
            'total_chars': sum(c['chars'] for c in chaps),
            'marks': len(marks), 'index_count': len(entries)}

def apply_fix(md_path, res):
    """按审计 plan 修复:先内容健康修复,再图片剔除/搬正/补插。备份 <原名>.bak.md,原地写回。返回动作数。"""
    text = open(md_path, encoding='utf-8', errors='ignore').read()
    if any(l == 'red' and ('打散' in t or '重复' in t) for l, t in res['items']):
        text = health_repair(text)
    lines, heads = parse_doc(text)
    plan = res['plan']
    # 重新定位(修复健康后行号变了):strip 按 (id 全部现存位置是否需删) 重算;insert 重找锚点
    strips = {p['id'] for p in plan if p['act'] == 'strip'}
    inserts = [p['id'] for p in plan if p['act'] == 'insert']
    keep_ids = {i['id'] for i in res['images'] if i['action'].startswith('保留')}
    n = 0
    if strips:
        out = []
        for ln in lines:
            def _sub(m):
                nonlocal n
                rid = m.group(1).strip()
                if rid in strips and rid not in keep_ids:
                    n += 1
                    return '' if rid in inserts or rid in {p['id'] for p in plan if p['act'] == 'insert'} else ('〔配图待人工:%s〕' % rid)
                return m.group(0)
            out.append(MARKER_RE.sub(_sub, ln))
        lines = out
        # 清掉因剔除产生的空行痕迹
        lines = [ln for k, ln in enumerate(lines) if ln.strip() or (k > 0 and lines[k - 1].strip())]
        _, heads = parse_doc('\n'.join(lines))
    entries, _, _ = load_index(res.get('materials'))
    byid = {e['id']: e for e in entries}
    for rid in dict.fromkeys(inserts):
        e = byid.get(rid)
        if not e: continue
        target, _ = find_anchor(e.get('anchor', ''), e.get('keywords', ''), lines, heads)
        if not target: continue
        at = insert_point(target, lines, heads)
        cap = ('|' + e['caption']) if e.get('caption') else ''
        lines[at:at] = ['', '{{图:%s%s}}' % (rid, cap), '']
        n += 1
        _, heads = parse_doc('\n'.join(lines))
    bak = md_path + '.bak.md'
    if not os.path.exists(bak):
        import shutil; shutil.copyfile(md_path, bak)
    open(md_path, 'w', encoding='utf-8').write('\n'.join(lines).strip() + '\n')
    return n

def write_report(path, md_name, res, fixed_n=None, images_pre=None):
    icon = {'green': '✅', 'yellow': '🟡', 'red': '🔴'}[res['level']]
    L = ['# 成品质检报告 · %s' % md_name, '',
         '**结论:%s %s**' % (icon, {'green': '通过', 'yellow': '有建议项', 'red': '有必须处理项'}[res['level']]),
         '']
    if fixed_n is not None:
        L.append('已自动修复动作:**%d** 处(原稿备份为 *.bak.md)。' % fixed_n)
        L.append('')
    L += ['## 一、问题清单', ''] + (['- %s %s' % ('🔴' if l == 'red' else '🟡', t) for l, t in res['items']] or ['- 无']) + ['']
    L += ['## 二、章节字数(总计 %d 字)' % res['total_chars'], '', '| 章节 | 字数 |', '|---|---|']
    L += ['| %s | %d |' % (c['title'], c['chars']) for c in res['chapters']] or ['| (未识别到章节) | - |']
    L += ['', '## 三、配图核对(索引 %d 张 / 文中打标 %d 处)' % (res['index_count'], res['marks']), '',
          '| 图片ID | 落位依据 | 动作 |', '|---|---|---|']
    _imgs = images_pre if images_pre else res['images']
    L += ['| %s | %s | %s |' % (i['id'], i['where'], i['action']) for i in _imgs] or ['| (无索引图) | - | - |']
    if res['coverage']:
        c = res['coverage']
        L += ['', '## 四、应答覆盖', '', '评分点 %d 条,偏离表 %d 条,覆盖率 **%d%%**。'
              % (c['score_rows'], c['deviation_rows'], c['ratio'] * 100)]
    L += ['', '> 本报告由确定性脚本 quality_gate.py 生成,不消耗模型 token。']
    open(path, 'w', encoding='utf-8').write('\n'.join(L) + '\n')

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('inp'); ap.add_argument('--materials', default=None)
    ap.add_argument('--fix', action='store_true'); ap.add_argument('--min-chapter', type=int, default=3500)
    ap.add_argument('--score', default=None); ap.add_argument('--deviation', action='append', default=[])
    ap.add_argument('--report', default=None)
    a = ap.parse_args()
    res = audit(a.inp, materials=a.materials, min_chapter=a.min_chapter, score=a.score, deviations=a.deviation)
    fixed, pre_images = None, None
    if a.fix and (res['plan'] or res['level'] == 'red'):
        pre_images = res['images']
        fixed = apply_fix(a.inp, res)
        res = audit(a.inp, materials=a.materials, min_chapter=a.min_chapter, score=a.score, deviations=a.deviation)
    rep = a.report or os.path.join(os.path.dirname(os.path.abspath(a.inp)), '成品质检报告.md')
    write_report(rep, os.path.basename(a.inp), res, fixed, images_pre=pre_images)
    print('质检:%s | 章节 %d 个 共 %d 字 | 图片动作 %d | 报告 → %s'
          % (res['level'], len(res['chapters']), res['total_chars'], len(res['plan']), rep))
    for l, t in res['items']: print(' -', '🔴' if l == 'red' else '🟡', t)
    sys.exit(2 if res['level'] == 'red' else (1 if res['level'] == 'yellow' else 0))

if __name__ == '__main__':
    main()
