#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
出 Word · 投标文件格式化导出（便携版，仅依赖 python-docx）
用法：python3 build_tender_docx.py 汇总好的方案.md 输出.docx \
        [--title "项目名称"] [--bidder "投标人名称"] [--subtitle "投标文件（技术标）"] \
        [--format-spec word_format_spec.json] [--images-dir 素材目录] [--repeat-images]

不带 --format-spec 时输出"标准国内标书格式"：
  标题1=黑体三号 / 标题2=黑体四号 / 标题3=宋体小四加粗 / 正文=宋体小四·1.5倍行距·首行缩进2字符·两端对齐
  A4 纸 + 封面 + 自动目录(域,打开F9更新) + 页眉(项目名)/页脚(页码) + 表格 + 流程图
  页码分节：封面/目录不编页码，正文单独分节从第 1 页起（标书惯例；可用 page_numbering 关闭）

带 --format-spec 时按招标书识别出的格式要求覆盖默认值（由"格式提取员"产出该 JSON），
可控制：纸张/页边距/装订线、正文与标题(h1–h4)字体字号、中西文字体分设(ascii_font)、行距、
首行缩进、对齐、标题编号、页眉页脚、页码分节方案、目录、封面规格(字号/信息栏)、表格格式、图编号样式。
JSON 结构见随附 word_format_spec_示例.json；未给的字段一律用国内标书默认值，向后兼容。
spec 中出现规范外的字段会打印告警（多为提取员拼写错误），并在导出后打印"生效格式摘要"供核对。
导出后用同目录 check_docx_format.py 对成品做格式自检（逐项核验 docx 是否符合 spec）。

图片自动插入（打标）：正文里的 {{图:图片ID}} / {{图:ID|图注}} / 〔图:ID〕 / ![图注](路径)
  导出时自动替换成素材库真图：等比缩放进版心、居中、按 figure_caption 样式连续编号图注（与流程图共用编号）。
  图片ID 到 素材目录/图片索引.md(json) 里查文件与默认图注；无索引则把 ID 当文件名在素材目录找。
  --images-dir 不传时自动找 <输入md同目录>/素材；缺图不报错→留〔需人工插入〕占位并在结束时汇总提醒。
  表格单元格里的打标同样会插图（缩到单元格适配尺寸，并在图下编号）。语法解析见同目录 tender_images.py（需一并拷走）。
  同图去重（默认开）：同一图片被多处打标（如偏离表几十条应答共用一张功能截图）时，首次插整图并编号，
  其余位置自动改写为"（见图N）"引用——加 --repeat-images 可改回每处都插整图。

样式联动（关键）：标题套内置"标题1/2/3/4"，正文套"正文"样式，图注套"Caption"样式——WPS/Word 样式面板可一键批量改。
依赖：pip install python-docx ；流程图渲染需 mermaid-cli/npx(可选,缺则降级为图注)
"""
import sys, re, os, json, subprocess, shutil, argparse, struct, copy
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from tender_images import ImageLibrary, has_image_marker, split_image_markers, fit_image
except ImportError:  # tender_images.py 未随脚本拷贝：打标降级为占位文本，不中断导出
    ImageLibrary = None
    has_image_marker = lambda t: False
    split_image_markers = lambda t: [('text', t, None)]
    fit_image = lambda p, w, h: (w, None)

# ---------------- 格式规范：默认值 = 标准国内标书格式 ----------------
DEFAULT_SPEC = {
    "page": {  # 纸张与页边距
        "size": "A4",                      # A4/A3/B5/16K/Letter 或 {"w_cm":21,"h_cm":29.7}
        "orientation": "portrait",         # portrait/landscape
        "margins_cm": {"top": 2.54, "bottom": 2.54, "left": 3.18, "right": 3.18},
        "gutter_cm": 0,                    # 装订线（招标要求"预留装订线X厘米"时填）
    },
    "body": {  # 正文
        "font": "宋体", "size": "小四",     # size 可写中文字号("小四")或磅数(12)
        "ascii_font": None,                # 西文/数字字体，如 "Times New Roman"；None=与中文同字体
        "align": "justify",                # 两端对齐(标书惯例)；left/center/right/justify
        "line_spacing": 1.5,               # 数字=倍数；或 {"rule":"fixed","pt":22} 固定值
        "first_line_indent_chars": 2,      # 首行缩进字符数，0=不缩进
        "space_before_pt": 0, "space_after_pt": 0,
    },
    "headings": {
        "h1": {"font": "黑体", "size": "三号", "bold": True, "align": "left", "ascii_font": None,
               "space_before_pt": 12, "space_after_pt": 8, "line_spacing": None, "numbering": None},  # numbering 如 "第{n}章"
        "h2": {"font": "黑体", "size": "四号", "bold": True, "align": "left", "ascii_font": None,
               "space_before_pt": 8, "space_after_pt": 4, "line_spacing": None, "numbering": None},   # 如 "{n}.{m}"
        "h3": {"font": "宋体", "size": "小四", "bold": True, "align": "left", "ascii_font": None,
               "space_before_pt": 4, "space_after_pt": 2, "line_spacing": None, "numbering": None},   # 如 "{n}.{m}.{k}"
        "h4": {"font": "宋体", "size": "小四", "bold": True, "align": "left", "ascii_font": None,
               "space_before_pt": 4, "space_after_pt": 2, "line_spacing": None, "numbering": None},   # 如 "{n}.{m}.{k}.{l}"
    },
    "header": {"enabled": True, "text": "{title}", "font": "宋体", "size": "小五", "ascii_font": None, "align": "center"},
    "footer": {"enabled": True, "format": "第 {page} 页", "font": "宋体", "size": "小五", "ascii_font": None, "align": "center"},
    #           footer.format 支持 {page} 当前页 / {pages} 总页数，如 "{page}/{pages}" 或 "- {page} -"
    "page_numbering": {  # 页码分节方案（招标常见要求："正文页码从1开始连续编号""封面不编页码"）
        "body_restart": True,              # True=封面/目录单独成节不计页码，正文分节后从 start_at 重新起算
        "front_format": None,              # 封面目录区页码：None=不显示 / "roman"=Ⅰ、Ⅱ…
        "start_at": 1,
    },
    "toc": {"enabled": True, "levels": 3, "title": "目录"},
    "cover": {  # 封面规格（招标规定封面格式时可整体控制）
        "enabled": True, "subtitle": "投 标 技 术 方 案",  # subtitle=文件性质行(如"投标文件（技术标）")
        "title_font": None, "title_size": "一号",          # None=用 h1 字体
        "subtitle_font": None, "subtitle_size": "小二",
        "info_font": None, "info_size": "四号",            # 信息栏；None=用正文字体
        "fields": None,   # 信息栏自定义行，如 [{"label":"招标编号","value":"XXX"},{"label":"投标人（盖章）","value":""}]
        "show_date": True,
    },
    "table": {  # 正文表格
        "style": "Table Grid",
        "font": None,                      # None=正文字体
        "ascii_font": None,
        "size": "五号",
        "align": "left",                   # 单元格文字对齐 left/center
        "header_bold": True,
    },
    "figure_caption": {"enabled": True, "style": "图{n}", "font": "宋体", "size": "五号"},
    # attachments_order：附件/格式件顺序，本脚本不重排正文（由汇总员按此顺序拼装 md），此处仅容忍存在
    "attachments_order": None,
}

CN_SIZE = {"初号": 42, "小初": 36, "一号": 26, "小一": 24, "二号": 22, "小二": 18,
           "三号": 16, "小三": 15, "四号": 14, "小四": 12, "五号": 10.5, "小五": 9,
           "六号": 7.5, "小六": 6.5, "七号": 5.5, "八号": 5}
PAGE_SIZE = {"A4": (21.0, 29.7), "A3": (29.7, 42.0), "B5": (17.6, 25.0),
             "16K": (18.4, 26.0), "16开": (18.4, 26.0), "LETTER": (21.59, 27.94)}
ALIGN = {"left": WD_ALIGN_PARAGRAPH.LEFT, "center": WD_ALIGN_PARAGRAPH.CENTER,
         "right": WD_ALIGN_PARAGRAPH.RIGHT, "justify": WD_ALIGN_PARAGRAPH.JUSTIFY}

def pt_of(size):
    """'小四'/'三号'/12/'12' → 磅数"""
    if isinstance(size, (int, float)): return float(size)
    s = str(size).strip().replace("pt", "").replace("磅", "")
    if s in CN_SIZE: return CN_SIZE[s]
    try: return float(s)
    except ValueError: return 12.0

def deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        out[k] = deep_merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out

def unknown_keys(user, tmpl, path=''):
    """递归找出 spec 里规范之外的字段名（多为格式提取员拼写错误），返回 ['body.fnt', ...]"""
    bad = []
    if not isinstance(user, dict) or not isinstance(tmpl, dict): return bad
    for k, v in user.items():
        if str(k).startswith('_'): continue   # _说明 之类注释字段
        if k not in tmpl: bad.append(path + str(k))
        else: bad.extend(unknown_keys(v, tmpl[k], path + str(k) + '.'))
    return bad

def load_spec(path):
    if not path: return copy.deepcopy(DEFAULT_SPEC)
    with open(path, encoding="utf-8") as f: user = json.load(f)
    for k in unknown_keys(user, DEFAULT_SPEC):
        print('⚠️ 格式 spec 未识别字段(疑似拼写错误,已忽略): %s' % k, file=sys.stderr)
    return deep_merge(DEFAULT_SPEC, user)

# ---------------- 底层工具 ----------------
def _set_rfonts(rPr, font, ascii_font=None):
    """中西文字体分设：eastAsia/cs=中文字体，ascii/hAnsi=西文字体(未指定则同中文)"""
    rf = rPr.find(qn('w:rFonts'))
    if rf is None: rf = OxmlElement('w:rFonts'); rPr.insert(0, rf)
    latin = ascii_font or font
    rf.set(qn('w:ascii'), latin); rf.set(qn('w:hAnsi'), latin)
    rf.set(qn('w:eastAsia'), font); rf.set(qn('w:cs'), font)

def _first_line_chars(pf_element, chars):
    """首行缩进按'字符数'精确设置(firstLineChars)，字号变了缩进跟着变"""
    pPr = pf_element.get_or_add_pPr()
    ind = pPr.find(qn('w:ind'))
    if ind is None: ind = OxmlElement('w:ind'); pPr.append(ind)
    ind.set(qn('w:firstLineChars'), str(int(chars * 100)))

def _apply_line_spacing(pf, ls):
    if isinstance(ls, dict):
        if ls.get("rule") == "fixed":
            pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY; pf.line_spacing = Pt(float(ls.get("pt", 22)))
            return
        ls = ls.get("multiple", 1.5)
    ls = float(ls)
    if abs(ls - 1.0) < 1e-6: pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
    else: pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE; pf.line_spacing = ls

def _pg_num_type(sec, start=None, fmt=None):
    """sectPr/w:pgNumType：页码起始值与编号格式（按 OOXML 顺序插到 w:cols 之前）"""
    sectPr = sec._sectPr
    el = sectPr.find(qn('w:pgNumType'))
    if el is None:
        el = OxmlElement('w:pgNumType')
        for tag in ('w:cols', 'w:formProt', 'w:vAlign', 'w:docGrid'):
            ref = sectPr.find(qn(tag))
            if ref is not None: ref.addprevious(el); break
        else: sectPr.append(el)
    if start is not None: el.set(qn('w:start'), str(int(start)))
    if fmt: el.set(qn('w:fmt'), fmt)

def set_style(style, font, size_pt, bold, ascii_font=None, first_indent_chars=None,
              before=None, after=None, line_spacing=None, align=None):
    style.font.name = font; style.font.size = Pt(size_pt); style.font.bold = bold
    style.font.color.rgb = RGBColor(0, 0, 0)
    _set_rfonts(style.element.get_or_add_rPr(), font, ascii_font)
    pf = style.paragraph_format
    if first_indent_chars is not None:
        if first_indent_chars: _first_line_chars(style.element, first_indent_chars)
        else: pf.first_line_indent = Pt(0)
    if before is not None: pf.space_before = Pt(before)
    if after is not None: pf.space_after = Pt(after)
    if line_spacing is not None: _apply_line_spacing(pf, line_spacing)
    if align is not None: pf.alignment = ALIGN.get(align, WD_ALIGN_PARAGRAPH.LEFT)

def style_doc(doc, spec):
    b = spec["body"]
    set_style(doc.styles['Normal'], b["font"], pt_of(b["size"]), False,
              ascii_font=b.get("ascii_font"),
              first_indent_chars=b.get("first_line_indent_chars", 2),
              before=b.get("space_before_pt", 0), after=b.get("space_after_pt", 0),
              line_spacing=b.get("line_spacing", 1.5),
              align=b.get("align", "justify"))
    for lvl, key in ((1, 'h1'), (2, 'h2'), (3, 'h3'), (4, 'h4')):
        h = spec["headings"][key]
        st = doc.styles['Heading %d' % lvl]
        set_style(st, h["font"], pt_of(h["size"]), h.get("bold", True),
                  ascii_font=h.get("ascii_font"), first_indent_chars=0,
                  before=h.get("space_before_pt", 0), after=h.get("space_after_pt", 0),
                  line_spacing=h.get("line_spacing"),
                  align=h.get("align", "left"))
    # 图注专用样式：不占用 Normal（避免"正文直接格式抽查"误报），样式面板可整体改
    fs = spec["figure_caption"]
    try: cap = doc.styles['Caption']
    except KeyError: cap = doc.styles.add_style('Caption', WD_STYLE_TYPE.PARAGRAPH)
    set_style(cap, fs.get("font", b["font"]), pt_of(fs.get("size", "五号")), False,
              ascii_font=fs.get("ascii_font") or b.get("ascii_font"),
              first_indent_chars=0, before=2, after=6, line_spacing=1.0, align="center")

def apply_page(sec, spec):
    """把纸张/边距/装订线应用到一个节（分节后新节虽会继承，显式设置更稳）"""
    p = spec["page"]
    size = p.get("size", "A4")
    if isinstance(size, dict): w, h = float(size.get("w_cm", 21)), float(size.get("h_cm", 29.7))
    else: w, h = PAGE_SIZE.get(str(size).upper(), PAGE_SIZE["A4"])
    if str(p.get("orientation", "portrait")).lower() == "landscape":
        w, h = max(w, h), min(w, h); sec.orientation = WD_ORIENT.LANDSCAPE
    sec.page_width = Cm(w); sec.page_height = Cm(h)
    m = p.get("margins_cm", {})
    sec.top_margin = Cm(float(m.get("top", 2.54))); sec.bottom_margin = Cm(float(m.get("bottom", 2.54)))
    sec.left_margin = Cm(float(m.get("left", 3.18))); sec.right_margin = Cm(float(m.get("right", 3.18)))
    if float(p.get("gutter_cm", 0) or 0) > 0: sec.gutter = Cm(float(p["gutter_cm"]))

def fig_geom(spec):
    """图片可用最大框 = 版心（扣除装订线，留一点余量），竖图被高度卡住不撑满整页"""
    p = spec["page"]
    size = p.get("size", "A4")
    if isinstance(size, dict): w, h = float(size.get("w_cm", 21)), float(size.get("h_cm", 29.7))
    else: w, h = PAGE_SIZE.get(str(size).upper(), PAGE_SIZE["A4"])
    if str(p.get("orientation", "portrait")).lower() == "landscape": w, h = max(w, h), min(w, h)
    m = p.get("margins_cm", {})
    fig_w = w - float(m.get("left", 3.18)) - float(m.get("right", 3.18)) - float(p.get("gutter_cm", 0) or 0) - 0.5
    fig_h = min(15.0, h - float(m.get("top", 2.54)) - float(m.get("bottom", 2.54)) - 6.0)
    return fig_w, fig_h

def cn_run(p, text, cn, size_pt, bold=False, ascii_font=None):
    r = p.add_run(text); r.font.name = cn; r.font.size = Pt(size_pt); r.font.bold = bold
    r.font.color.rgb = RGBColor(0, 0, 0); _set_rfonts(r._element.get_or_add_rPr(), cn, ascii_font); return r

def special(doc, text, cn, size_pt, bold=False, align=None, ascii_font=None):
    p = doc.add_paragraph(); p.paragraph_format.first_line_indent = Pt(0)
    if align is not None: p.alignment = align
    cn_run(p, text, cn, size_pt, bold, ascii_font=ascii_font); return p

def cap_par(doc, text):
    """图注/图引用段：套 Caption 样式（字体字号对齐由 style_doc 统一设定）"""
    return doc.add_paragraph(text, style='Caption')

INLINE = re.compile(r'(\*\*.+?\*\*|\*[^*\s][^*]*\*|`[^`]+`)')

def body_par(doc, text):
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)  # [文字](链接) → 文字
    p = doc.add_paragraph()
    for seg in INLINE.split(text):
        if not seg: continue
        if seg.startswith('**') and seg.endswith('**') and len(seg) > 4:
            p.add_run(seg[2:-2]).bold = True
        elif seg.startswith('`') and seg.endswith('`') and len(seg) > 2:
            p.add_run(seg[1:-1])
        elif seg.startswith('*') and seg.endswith('*') and len(seg) > 2:
            p.add_run(seg[1:-1]).italic = True
        else:
            p.add_run(seg)
    return p

def add_toc(doc, spec):
    t = spec["toc"]
    if not t.get("enabled", True): return False
    special(doc, t.get("title", "目录"), spec["headings"]["h1"]["font"], pt_of(spec["headings"]["h1"]["size"]),
            True, align=WD_ALIGN_PARAGRAPH.CENTER)
    p = doc.add_paragraph(); r = p.add_run()
    lv = int(t.get("levels", 3))
    f1 = OxmlElement('w:fldChar'); f1.set(qn('w:fldCharType'), 'begin'); r._r.append(f1)
    it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve')
    it.text = 'TOC \\o "1-%d" \\h \\z \\u' % max(1, min(lv, 9)); r._r.append(it)
    f2 = OxmlElement('w:fldChar'); f2.set(qn('w:fldCharType'), 'separate'); r._r.append(f2)
    rt = OxmlElement('w:t'); rt.set(qn('xml:space'), 'preserve')
    rt.text = '（目录将在 Word/WPS 打开后自动生成；若未刷新请按 F9 或右键"更新域"）'; r._r.append(rt)
    f3 = OxmlElement('w:fldChar'); f3.set(qn('w:fldCharType'), 'end'); r._r.append(f3)
    st = doc.settings.element
    uf = OxmlElement('w:updateFields'); uf.set(qn('w:val'), 'true')
    anchor = None
    for tag in ('w:hdrShapeDefaults', 'w:footnotePr', 'w:endnotePr', 'w:compat', 'w:rsids'):
        e = st.find(qn(tag))
        if e is not None: anchor = e; break
    anchor.addprevious(uf) if anchor is not None else st.append(uf)
    return True

def _page_field(par, instr, font, size_pt, ascii_font=None):
    fld = OxmlElement('w:fldSimple'); fld.set(qn('w:instr'), ' %s \\* MERGEFORMAT ' % instr)
    run = OxmlElement('w:r'); rpr = OxmlElement('w:rPr'); rfo = OxmlElement('w:rFonts')
    latin = ascii_font or font
    rfo.set(qn('w:ascii'), latin); rfo.set(qn('w:hAnsi'), latin)
    rfo.set(qn('w:eastAsia'), font); rfo.set(qn('w:cs'), font)
    sz = OxmlElement('w:sz'); sz.set(qn('w:val'), str(int(size_pt * 2)))
    rpr.append(rfo); rpr.append(sz)
    t = OxmlElement('w:t'); t.text = '1'; run.append(rpr); run.append(t); fld.append(run)
    par._p.append(fld)

def _write_footer(par, fmt, font, sz, ascii_font, pages_instr):
    """按 {page}/{pages} 切段，域和文字交错写入"""
    for part in re.split(r'(\{page\}|\{pages\})', fmt):
        if part == '{page}': _page_field(par, 'PAGE', font, sz, ascii_font)
        elif part == '{pages}': _page_field(par, pages_instr, font, sz, ascii_font)
        elif part: cn_run(par, part, font, sz, ascii_font=ascii_font)

def add_header_footer(section, spec, title, pages_instr='NUMPAGES'):
    hd = spec["header"]
    if hd.get("enabled", True):
        section.header.is_linked_to_previous = False
        h = section.header.paragraphs[0]
        h.alignment = ALIGN.get(hd.get("align", "center"), WD_ALIGN_PARAGRAPH.CENTER)
        text = str(hd.get("text", "{title}")).replace("{title}", title)[:60]
        cn_run(h, text, hd.get("font", "宋体"), pt_of(hd.get("size", "小五")), ascii_font=hd.get("ascii_font"))
    ft = spec["footer"]
    if ft.get("enabled", True):
        section.footer.is_linked_to_previous = False
        f = section.footer.paragraphs[0]
        f.alignment = ALIGN.get(ft.get("align", "center"), WD_ALIGN_PARAGRAPH.CENTER)
        _write_footer(f, str(ft.get("format", "第 {page} 页")), ft.get("font", "宋体"),
                      pt_of(ft.get("size", "小五")), ft.get("ascii_font"), pages_instr)

def add_front_page_number(section, spec):
    """封面/目录节的罗马页码（page_numbering.front_format == "roman" 时）"""
    ft = spec["footer"]
    _pg_num_type(section, start=1, fmt='upperRoman')
    section.footer.is_linked_to_previous = False
    f = section.footer.paragraphs[0]
    f.alignment = ALIGN.get(ft.get("align", "center"), WD_ALIGN_PARAGRAPH.CENTER)
    _page_field(f, 'PAGE', ft.get("font", "宋体"), pt_of(ft.get("size", "小五")), ft.get("ascii_font"))

def add_cover(doc, spec, title, bidder):
    c = spec["cover"]
    if not c.get("enabled", True): return False
    h1f = spec["headings"]["h1"]["font"]; bf = spec["body"]["font"]
    tf = c.get("title_font") or h1f; sf = c.get("subtitle_font") or h1f; inf = c.get("info_font") or bf
    tsz = pt_of(c.get("title_size", "一号")); ssz = pt_of(c.get("subtitle_size", "小二")); isz = pt_of(c.get("info_size", "四号"))
    for _ in range(6): doc.add_paragraph()
    special(doc, title, tf, tsz, True, align=WD_ALIGN_PARAGRAPH.CENTER)
    doc.add_paragraph()
    special(doc, c.get("subtitle", "投 标 技 术 方 案"), sf, ssz, True, align=WD_ALIGN_PARAGRAPH.CENTER)
    for _ in range(8): doc.add_paragraph()
    fields = c.get("fields")
    if fields:
        for fd in fields:
            special(doc, '%s：%s' % (fd.get("label", ""), str(fd.get("value", "") or "")),
                    inf, isz, align=WD_ALIGN_PARAGRAPH.CENTER)
    else:
        special(doc, f'投标人（盖章）：{bidder}', inf, isz, align=WD_ALIGN_PARAGRAPH.CENTER)
    if c.get("show_date", True):
        special(doc, '日　　期：　　年　　月　　日', inf, isz, align=WD_ALIGN_PARAGRAPH.CENTER)
    return True

# ---------------- 标题自动编号 ----------------
class Numberer:
    """按 spec.headings.hN.numbering 给标题加编号前缀；标题本身已带编号则不重复加"""
    ALREADY = re.compile(r'^\s*(第[\d一二三四五六七八九十百]+[章节部分]|[\d一二三四五六七八九十]+[、.．)）]|\d+(\.\d+)+)')
    def __init__(self, spec):
        self.fmt = {i: spec["headings"]['h%d' % i].get("numbering") for i in (1, 2, 3, 4)}
        self.n = [0, 0, 0, 0]
    def text(self, level, raw):
        lv = min(level, 4)
        self.n[lv - 1] += 1
        for i in range(lv, 4): self.n[i] = 0
        fmt = self.fmt.get(lv)
        if not fmt or self.ALREADY.match(raw): return raw
        pre = (fmt.replace('{n}', str(self.n[0])).replace('{m}', str(self.n[1]))
                  .replace('{k}', str(self.n[2])).replace('{l}', str(self.n[3])))
        return f'{pre} {raw}'

# ---------------- mermaid / 表格 ----------------
def render_mermaid(code, outdir, idx):
    src = os.path.join(outdir, f'_mmd_{idx}.mmd'); png = os.path.join(outdir, f'_mmd_{idx}.png')
    open(src, 'w', encoding='utf-8').write(code)
    try:
        if shutil.which('mmdc'):
            subprocess.run(['mmdc', '-i', src, '-o', png, '-e', 'png', '-s', '2'], check=True, capture_output=True, timeout=120)
        elif shutil.which('npx'):
            subprocess.run(['npx', '-y', '@mermaid-js/mermaid-cli', '-i', src, '-o', png, '-e', 'png', '-s', '2'],
                           check=True, capture_output=True, timeout=240)
        else: return None
        return png if os.path.exists(png) else None
    except Exception: return None

def png_size(path):
    try:
        with open(path, 'rb') as f: head = f.read(24)
        if head[:8] == b'\x89PNG\r\n\x1a\n' and head[12:16] == b'IHDR':
            w, h = struct.unpack('>II', head[16:24]); return (w, h)
    except Exception: pass
    return None

def fit_box(path, max_w, max_h):
    dim = png_size(path)
    if not dim or dim[1] == 0: return (Cm(max_w), None)
    asp = dim[0] / dim[1]
    if asp >= max_w / max_h: return (Cm(max_w), Cm(max_w / asp))
    return (Cm(max_h * asp), Cm(max_h))

def parse_table(lines):
    rows = []
    for ln in lines:
        if set(ln.replace('|', '').replace('-', '').replace(':', '').strip()) == set(): continue
        rows.append([c.strip() for c in ln.strip().strip('|').split('|')])
    return rows

# ---------------- 图片打标插入 ----------------
def fig_caption_text(fig_spec, n, title=None):
    pre = str(fig_spec.get("style", "图{n}")).replace('{n}', str(n))
    return '%s %s' % (pre, title) if title else pre

def add_picture_par(doc, path, max_w, max_h):
    """居中插图（等比缩放进版心框，不放大超过原图）；失败返回 False"""
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Pt(0)
    w, h = fit_image(path, max_w, max_h)
    try:
        r = p.add_run()
        r.add_picture(path, width=Cm(w), height=Cm(h)) if h else r.add_picture(path, width=Cm(w))
        return True
    except Exception:
        p._p.getparent().remove(p._p)
        return False

def insert_marked_image(doc, imglib, ref, custom_cap, fig, fig_w, fig_h, fig_spec, dedup=True):
    """处理一处 {{图:ref}} 打标：命中→插图+编号图注；同一图已插过(去重开)→"（见图N）"引用；未命中→占位提醒"""
    path, default_cap = imglib.resolve(ref)
    title = custom_cap or default_cap
    if path and dedup and path in imglib.fig_of:  # 多个应答点引同一截图：不重复插整图，指向首次编号
        cap_par(doc, '（见%s）' % fig_caption_text(fig_spec, imglib.fig_of[path], title))
        return True
    fig[0] += 1
    cap = fig_caption_text(fig_spec, fig[0], title or (None if path else ref))
    if path and add_picture_par(doc, path, fig_w, fig_h):
        imglib.inserted.append((ref, path)); imglib.fig_of.setdefault(path, fig[0])
        if fig_spec.get("enabled", True): cap_par(doc, cap)
        return True
    imglib.missing.append(ref)
    cap_par(doc, '〔%s：图片素材缺失，需人工插入〕' % cap)
    return False

def cell_marked_content(cell, text, imglib, font, sz, af, fig, fig_spec, dedup=True, bold=False):
    """表格单元格内容：打标处嵌小图并编号（偏离表"证明材料"列常用）；同图重复出现改写"（见图N）"引用"""
    par = cell.paragraphs[0]
    for kind, ref, _cap in split_image_markers(text):
        if kind == 'text':
            if ref.strip(): cn_run(par, ref.strip(), font, sz, bold=bold, ascii_font=af)
            continue
        path, _ = imglib.resolve(ref)
        if path and dedup and path in imglib.fig_of:
            cn_run(par, '（见%s）' % fig_caption_text(fig_spec, imglib.fig_of[path]), font, sz, bold=bold, ascii_font=af)
            continue
        done = False
        if path:
            w, h = fit_image(path, 6.0, 8.0)
            try:
                r = par.add_run()
                r.add_picture(path, width=Cm(w), height=Cm(h)) if h else r.add_picture(path, width=Cm(w))
                imglib.inserted.append((ref, path)); done = True
                if dedup:  # 编号写在图下方，供后续"（见图N）"引用定位
                    fig[0] += 1; imglib.fig_of.setdefault(path, fig[0])
                    p2 = cell.add_paragraph(); p2.paragraph_format.first_line_indent = Pt(0)
                    cn_run(p2, fig_caption_text(fig_spec, fig[0]), font, 9, ascii_font=af)
            except Exception: done = False
        if not done:
            imglib.missing.append(ref)
            cn_run(par, '〔图 %s：素材缺失，需人工插入〕' % ref, font, sz, bold=bold, ascii_font=af)

# ---- 宽表适配:固定列宽 + 字号自降 + 超宽自动横排,治"每列一个字"的竖排病 ----
TBL_MIN_COL_CM = 1.1          # 任何列不得窄于此(约两个小五汉字);Word 自动布局对无空格中文会压到一字一行
TBL_LANDSCAPE_AT = 10         # 列数达到该值:该表独占横排页(标书宽清单惯例),前后自动分节、页码连续

def _disp_len(s):
    """显示宽度估算:汉字记 1,西文/数字记 0.55"""
    return sum(1.0 if ord(ch) > 0x2E7F else 0.55 for ch in str(s)) or 1.0

def _tbl_content_w(spec, landscape=False):
    p = spec["page"]; size = p.get("size", "A4")
    if isinstance(size, dict): w, h = float(size.get("w_cm", 21)), float(size.get("h_cm", 29.7))
    else: w, h = PAGE_SIZE.get(str(size).upper(), PAGE_SIZE["A4"])
    if landscape or str(p.get("orientation", "portrait")).lower() == "landscape": w = max(w, h)
    m = p.get("margins_cm", {})
    return w - float(m.get("left", 3.18)) - float(m.get("right", 3.18)) - float(p.get("gutter_cm", 0) or 0)

def _col_widths(rows, ncols, avail):
    """按各列最长内容分配列宽:序号/单位类列窄,描述列宽;窄列有保底,超出从宽列按比例扣回"""
    need = []
    for ci in range(ncols):
        mx = max((_disp_len(r[ci]) for r in rows if ci < len(r) and str(r[ci]).strip()), default=2.0)
        need.append(min(max(mx, 2.0), 26.0))
    w = [avail * x / sum(need) for x in need]
    for _ in range(ncols):
        lack = sum(TBL_MIN_COL_CM - x for x in w if x < TBL_MIN_COL_CM)
        if lack <= 1e-6: break
        rich = [i for i, x in enumerate(w) if x > TBL_MIN_COL_CM + 1e-6]
        if not rich: break
        pool = sum(w[i] - TBL_MIN_COL_CM for i in rich)
        for i in rich: w[i] -= lack * (w[i] - TBL_MIN_COL_CM) / pool
        w = [max(x, TBL_MIN_COL_CM) for x in w]
    return w

def _tbl_fixed_layout(t, widths):
    """固定布局 + 表宽 + 逐列 gridCol:Word/WPS 不再按内容重排,列宽即所设"""
    tblPr = t._tbl.tblPr
    el = tblPr.find(qn('w:tblLayout'))
    if el is None:
        el = OxmlElement('w:tblLayout'); tblPr.append(el)
    el.set(qn('w:type'), 'fixed')
    tw = tblPr.find(qn('w:tblW'))
    if tw is None:
        tw = OxmlElement('w:tblW'); tblPr.append(tw)
    tw.set(qn('w:w'), str(int(round(sum(widths) * 567)))); tw.set(qn('w:type'), 'dxa')
    grid = t._tbl.find(qn('w:tblGrid'))
    if grid is not None:
        for gc, wcm in zip(grid.findall(qn('w:gridCol')), widths):
            gc.set(qn('w:w'), str(int(round(wcm * 567))))

def _row_pr(row, tag):
    trPr = row._tr.get_or_add_trPr()
    if trPr.find(qn('w:' + tag)) is None: trPr.append(OxmlElement('w:' + tag))

def _spec_landscape(spec):
    s = copy.deepcopy(spec); s["page"]["orientation"] = "landscape"; return s

def add_table(doc, rows, spec, imglib=None, fig=None, dedup=True):
    ts = spec["table"]
    font = ts.get("font") or spec["body"]["font"]
    sz = pt_of(ts.get("size", "五号")); af = ts.get("ascii_font") or spec["body"].get("ascii_font")
    align = ALIGN.get(ts.get("align", "left"), WD_ALIGN_PARAGRAPH.LEFT)
    hdr_bold = bool(ts.get("header_bold", True))
    ncols = max(len(r) for r in rows)
    landscape = ncols >= TBL_LANDSCAPE_AT and str(spec["page"].get("orientation", "portrait")).lower() != "landscape"
    if landscape:                                   # 宽清单独占横排页,表后回纵排,页码/页眉延续
        apply_page(doc.add_section(WD_SECTION.NEW_PAGE), _spec_landscape(spec))
    avail = _tbl_content_w(spec, landscape=landscape)
    if ncols >= 12 or avail / ncols < 1.5: sz = min(sz, 8.0)     # 特宽表压到 8 磅
    elif ncols >= 8: sz = min(sz, 9.0)                           # 宽表小五
    elif ncols >= 6: sz = min(sz, 10.5)                          # 中宽表五号
    widths = _col_widths(rows, ncols, avail)
    center_cols = {ci for ci in range(ncols)                     # 序号/单位/数量这类短内容列整列居中
                   if all(_disp_len(r[ci]) <= 7 for r in rows[1:] if ci < len(r) and str(r[ci]).strip())}
    t = doc.add_table(rows=len(rows), cols=ncols)
    try: t.style = ts.get("style", "Table Grid") or "Table Grid"
    except KeyError: t.style = 'Table Grid'
    t.autofit = False
    _tbl_fixed_layout(t, widths)
    _row_pr(t.rows[0], 'tblHeader')                              # 跨页自动重复表头
    for ri, row in enumerate(rows):
        if max((len(str(c)) for c in row), default=0) <= 300:
            _row_pr(t.rows[ri], 'cantSplit')                     # 短行不跨页断开;长文本行放行
        for ci in range(ncols):
            cell = row[ci] if ci < len(row) else ''
            c = t.cell(ri, ci); c.width = Cm(widths[ci])
            c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p = c.paragraphs[0]; p.clear()
            p.paragraph_format.first_line_indent = Pt(0)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if (ri == 0 or ci in center_cols) else align
            if imglib is not None and fig is not None and has_image_marker(cell):
                cell_marked_content(c, cell, imglib, font, sz, af, fig, spec["figure_caption"],
                                    dedup=dedup, bold=(ri == 0 and hdr_bold))
            else:
                cn_run(p, cell, font, sz, bold=(ri == 0 and hdr_bold), ascii_font=af)
    if landscape:
        apply_page(doc.add_section(WD_SECTION.NEW_PAGE), spec)
    return t

# ---------------- 生效格式摘要 ----------------
def _fmt_ls(ls):
    if isinstance(ls, dict):
        return '固定值%s磅' % ls.get("pt") if ls.get("rule") == "fixed" else '%s倍' % ls.get("multiple", 1.5)
    return '单倍' if abs(float(ls) - 1.0) < 1e-6 else '%s倍' % ls

def print_applied(spec, restart):
    p, b = spec["page"], spec["body"]
    m = p.get("margins_cm", {})
    gutter = '｜装订线%scm' % p["gutter_cm"] if float(p.get("gutter_cm", 0) or 0) > 0 else ''
    print('  版面: %s %s｜边距(cm) 上%s 下%s 左%s 右%s%s' % (
        p.get("size", "A4"), '横向' if str(p.get("orientation")) == 'landscape' else '纵向',
        m.get("top", 2.54), m.get("bottom", 2.54), m.get("left", 3.18), m.get("right", 3.18), gutter))
    latin = '｜西文 %s' % b["ascii_font"] if b.get("ascii_font") else ''
    print('  正文: %s %s(%.4g磅)%s｜%s行距｜首行缩进%s字符｜%s' % (
        b["font"], b["size"], pt_of(b["size"]), latin, _fmt_ls(b.get("line_spacing", 1.5)),
        b.get("first_line_indent_chars", 2),
        {'justify': '两端对齐', 'left': '左对齐', 'center': '居中', 'right': '右对齐'}.get(b.get("align"), b.get("align"))))
    hs = []
    for k in ('h1', 'h2', 'h3', 'h4'):
        h = spec["headings"][k]
        num = ' 编号"%s"' % h["numbering"] if h.get("numbering") else ''
        hs.append('%s=%s%s%s' % (k, h["font"], h["size"], num))
    print('  标题: ' + '｜'.join(hs))
    if restart:
        front = '罗马页码' if spec["page_numbering"].get("front_format") == 'roman' else '不编页码'
        print('  页码: 封面/目录%s，正文分节后从第%s页起｜页脚"%s"' % (
            front, spec["page_numbering"].get("start_at", 1), spec["footer"].get("format")))
    else:
        print('  页码: 全文连续｜页脚"%s"' % spec["footer"].get("format"))

LEGACY_CN_FONTS = {'仿宋_GB2312', '楷体_GB2312'}

def collect_spec_fonts(spec):
    """spec 用到的全部字体名（正文/标题/页眉页脚/封面/表格/图注，含西文字体）——查看文档的机器需装齐这些字体"""
    fonts = set()
    def grab(d):
        for k in ('font', 'ascii_font', 'title_font', 'subtitle_font', 'info_font'):
            v = (d or {}).get(k)
            if v: fonts.add(str(v))
    for part in ('body', 'header', 'footer', 'figure_caption', 'table', 'cover'):
        grab(spec.get(part))
    for h in (spec.get('headings') or {}).values():
        grab(h)
    return fonts

def print_font_notes(spec):
    """跨平台观感一致性提醒：字体在查看机器上缺失时 Word 会替换显示（Mac/Windows 观感不一致的头号原因）"""
    fonts = collect_spec_fonts(spec)
    if not fonts: return
    print('  字体依赖: %s' % '、'.join(sorted(fonts)))
    print('    ↳ 打开/评标的电脑须已安装上述字体，缺失时 Word 自动替换显示，Mac 与 Windows、不同机器观感会不一样；')
    print('      终稿建议：在装齐字体的机器用 Word 把每册另存一份 PDF 随 docx 一并交付，观感就与对方机器无关了。')
    legacy = fonts & LEGACY_CN_FONTS
    if legacy:
        print('  ⚠️ %s 是 GB2312 老字体，很多电脑（含新装 Windows/Mac）没有——若招标书未逐字要求，建议 spec 改用 仿宋/楷体。'
              % '、'.join(sorted(legacy)))

# ---------------- 主流程 ----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('inp'); ap.add_argument('out')
    ap.add_argument('--title', default=None); ap.add_argument('--bidder', default='〔投标人全称〕')
    ap.add_argument('--subtitle', default=None, help='封面文件性质行，如"投标文件（商务标）"，覆盖 spec.cover.subtitle')
    ap.add_argument('--format-spec', default=None, help='格式提取员产出的 word_format_spec.json，覆盖默认国内标书格式')
    ap.add_argument('--images-dir', default=None, help='图片素材目录(含 图片索引.md/json)；默认自动找 <输入md同目录>/素材')
    ap.add_argument('--repeat-images', action='store_true',
                    help='同一图片被多处打标时每处都插整图（默认去重：首次插图编号，后续改写为"（见图N）"引用）')
    a = ap.parse_args()
    spec = load_spec(a.format_spec)
    if a.subtitle: spec["cover"]["subtitle"] = a.subtitle

    md = open(a.inp, encoding='utf-8').read().split('\n')
    outdir = os.path.dirname(os.path.abspath(a.out)) or '.'
    md_dir = os.path.dirname(os.path.abspath(a.inp)) or '.'
    imglib = ImageLibrary(a.images_dir, [md_dir, outdir]) if ImageLibrary else None
    dedup = not a.repeat_images
    doc = Document()
    apply_page(doc.sections[0], spec)
    fig_w, fig_h = fig_geom(spec)
    style_doc(doc, spec)

    title = a.title; body_start = 0
    for i, l in enumerate(md):
        if l.startswith('# ') and title is None:
            title = re.sub(r'^#\s*', '', l).strip(); body_start = i + 1; break
    title = title or '投标技术方案'

    # 封面/目录 → 前置节；正文按 page_numbering 决定是否分节重排页码
    pn = spec["page_numbering"]
    has_cover = add_cover(doc, spec, title, a.bidder)
    if has_cover and spec["toc"].get("enabled", True): doc.add_page_break()
    has_toc = add_toc(doc, spec)
    front = has_cover or has_toc
    restart = bool(pn.get("body_restart", True)) and front
    if restart:
        if pn.get("front_format") == 'roman' and spec["footer"].get("enabled", True):
            add_front_page_number(doc.sections[0], spec)
        body_sec = doc.add_section(WD_SECTION.NEW_PAGE)
        apply_page(body_sec, spec)
        _pg_num_type(body_sec, start=pn.get("start_at", 1))
    else:
        if front: doc.add_page_break()
        body_sec = doc.sections[0]
    add_header_footer(body_sec, spec, title, pages_instr='SECTIONPAGES' if restart else 'NUMPAGES')

    # 标题层级归一：若正文最高层级是 ##（md 里 # 只用作书名），把 ## 当作 标题1，依次类推
    levels = []; fence = False
    for ln in md[body_start:]:
        if ln.startswith('```'): fence = not fence; continue
        if fence: continue
        m = re.match(r'^(#{1,6})\s', ln)
        if m: levels.append(len(m.group(1)))
    if levels and levels[0] == 1: levels = levels[1:]  # 首个 h1 会被当书名跳过，不参与归一
    base = min(levels) if levels else 1

    numberer = Numberer(spec)
    fig_spec = spec["figure_caption"]
    bodyfont = spec["body"]["font"]
    i = body_start; first_h1_is_title = True; mmidx = 0; fig = [0]; mm_fail = 0
    while i < len(md):
        ln = md[i]
        if ln.strip() == '': i += 1; continue
        if ln.startswith('```'):
            lang = ln.strip('`').strip(); buf = []; i += 1
            while i < len(md) and not md[i].startswith('```'): buf.append(md[i]); i += 1
            i += 1
            if lang.lower() == 'mermaid':
                mmidx += 1; fig[0] += 1; png = render_mermaid('\n'.join(buf), outdir, mmidx)
                cap = fig_caption_text(fig_spec, fig[0])
                if png:
                    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.first_line_indent = Pt(0)
                    w, h = fit_box(png, fig_w, fig_h)
                    try:
                        if h is not None: p.add_run().add_picture(png, width=w, height=h)
                        else: p.add_run().add_picture(png, width=w)
                        if fig_spec.get("enabled", True): cap_par(doc, cap)
                    except Exception:
                        cap_par(doc, f'（{cap}）')
                else:
                    mm_fail += 1
                    cap_par(doc, f'（{cap}：见随附流程图源）')
            continue
        if ln.startswith('|') and i + 1 < len(md) and md[i + 1].strip().startswith('|'):
            tb = []
            while i < len(md) and md[i].strip().startswith('|'): tb.append(md[i]); i += 1
            rows = parse_table(tb)
            if rows: add_table(doc, rows, spec, imglib=imglib, fig=fig, dedup=dedup)
            continue
        m = re.match(r'^(#{1,6})\s', ln)
        if m:
            lvl = len(m.group(1))
            if lvl == 1 and first_h1_is_title: first_h1_is_title = False; i += 1; continue
            lvl = max(1, lvl - base + 1)  # 层级归一
            raw = re.sub(r'^#+\s*', '', ln).strip()
            doc.add_paragraph(numberer.text(lvl, raw), style='Heading %d' % min(lvl, 4))
            i += 1; continue
        if imglib and has_image_marker(ln):  # 图片打标行：{{图:ID}} / ![图注](路径)，文字与图按原顺序落版
            for kind, ref, cap in split_image_markers(re.sub(r'^\s*[-*]\s+|^>\s*', '', ln)):
                if kind == 'text':
                    if ref.strip(): body_par(doc, ref.strip())
                else:
                    insert_marked_image(doc, imglib, ref, cap, fig, fig_w, fig_h, fig_spec, dedup)
            i += 1; continue
        if re.match(r'^\s*[-*]\s+', ln): body_par(doc, '· ' + re.sub(r'^\s*[-*]\s+', '', ln)); i += 1; continue
        if re.match(r'^\s*\d+\.\s+', ln): body_par(doc, re.sub(r'^\s*', '', ln)); i += 1; continue
        if ln.startswith('>'): body_par(doc, ln.lstrip('> ').strip()); i += 1; continue
        if re.match(r'^---+$', ln.strip()): i += 1; continue
        body_par(doc, ln); i += 1

    z = doc.settings.element.find(qn('w:zoom'))
    if z is not None and z.get(qn('w:percent')) is None: z.set(qn('w:percent'), '100')
    doc.save(a.out)
    src = '（按 %s 应用招标书格式要求）' % os.path.basename(a.format_spec) if a.format_spec else '（标准国内标书默认格式）'
    print('已生成投标文件 Word %s：%s' % (src, a.out))
    print_applied(spec, restart)
    print_font_notes(spec)
    if mm_fail:
        print('⚠️ %d 处 Mermaid 流程图未渲染成图（本机缺 mermaid-cli/npx），已降级为图注——'
              '换环境重跑会得到不同的文档；建议安装后重新导出，保证各环境产物一致。' % mm_fail)
    if imglib:
        for line in imglib.report(): print(line)
    print('下一步格式自检：python3 %s "%s"%s' % (
        os.path.join(os.path.dirname(os.path.abspath(__file__)), 'check_docx_format.py'),
        a.out, ' --format-spec "%s"' % a.format_spec if a.format_spec else ''))

if __name__ == '__main__':
    main()
