#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
格式自检器 · 逐项核验生成的投标文件 docx 是否真的符合招标格式要求（word_format_spec.json）
用法：python3 check_docx_format.py 投标文件.docx [--format-spec word_format_spec.json] \
        [--title "项目名称"] [--report 格式自检报告.md]

- 不带 --format-spec 时按"标准国内标书默认格式"核验（与 build_tender_docx.py 的默认值一致）。
- 核验项：纸张/页边距/装订线、正文样式(字体/中西文分设/字号/行距/首行缩进/对齐)、
  标题1–4样式与编号前缀、页眉页脚(文字与页码域)、页码分节方案(封面目录不计页/正文从1起)、
  目录域、封面(性质行/标题)、表格样式与字体。
- 产出 Markdown 自检报告（默认写在 docx 旁），全部通过退出码 0，有不符项退出码 1 ——
  可作为出 Word 后的"格式门禁"：不通过就修 spec / 重新导出，直到通过。
- 本脚本只核验 Word 能承载的格式；装订/密封/签章等人工事项见 格式要求摘要.md。
依赖：pip install python-docx；需与 build_tender_docx.py 同目录（复用其默认格式定义）。
"""
import sys, os, re, json, argparse
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build_tender_docx import DEFAULT_SPEC, deep_merge, unknown_keys, pt_of, PAGE_SIZE, ALIGN, \
    collect_spec_fonts, LEGACY_CN_FONTS

EPS_CM = 0.06   # EMU 取整的厘米误差容忍
EPS_PT = 0.26   # 半磅存储的磅值误差容忍
ALIGN_CN = {"left": "左对齐", "center": "居中", "right": "右对齐", "justify": "两端对齐"}
ALIGN_ENUM = {k: v for k, v in ALIGN.items()}
ENUM_ALIGN = {v: k for k, v in ALIGN.items()}

def _sname(o):
    """安全取样式名:真实 docx 里 style 可能为 None(WPS/.doc 转换件常见),直接 .name 会崩"""
    try:
        st = getattr(o, 'style', None)
        return (st.name if st is not None and st.name else '') or ''
    except Exception:
        return ''

def load_spec(path):
    if not path: return deep_merge(DEFAULT_SPEC, {})
    with open(path, encoding='utf-8') as f: user = json.load(f)
    for k in unknown_keys(user, DEFAULT_SPEC):
        print('⚠️ 格式 spec 未识别字段(疑似拼写错误,核验时忽略): %s' % k, file=sys.stderr)
    return deep_merge(DEFAULT_SPEC, user)

def page_dims(spec):
    p = spec["page"]; size = p.get("size", "A4")
    if isinstance(size, dict): w, h = float(size.get("w_cm", 21)), float(size.get("h_cm", 29.7))
    else: w, h = PAGE_SIZE.get(str(size).upper(), PAGE_SIZE["A4"])
    if str(p.get("orientation", "portrait")).lower() == "landscape": w, h = max(w, h), min(w, h)
    return w, h

def rfonts_of(element_with_rpr):
    """(eastAsia, ascii) 字体名；element 为 style.element 或 run._element"""
    rpr = element_with_rpr.find(qn('w:rPr'))
    if rpr is None: return None, None
    rf = rpr.find(qn('w:rFonts'))
    if rf is None: return None, None
    return rf.get(qn('w:eastAsia')), rf.get(qn('w:ascii'))

def first_line_chars_of(style):
    pPr = style.element.find(qn('w:pPr'))
    if pPr is None: return None
    ind = pPr.find(qn('w:ind'))
    if ind is None: return None
    v = ind.get(qn('w:firstLineChars'))
    return int(v) / 100 if v else None

def ls_expected(ls):
    if isinstance(ls, dict) and ls.get("rule") == "fixed": return ('固定值', float(ls.get("pt", 22)))
    v = ls.get("multiple", 1.5) if isinstance(ls, dict) else float(ls)
    return ('单倍', 1.0) if abs(v - 1.0) < 1e-6 else ('倍数', v)

def ls_actual(pf):
    r, v = pf.line_spacing_rule, pf.line_spacing
    if r == WD_LINE_SPACING.EXACTLY: return ('固定值', round(v.pt, 2) if v is not None else None)
    if r == WD_LINE_SPACING.SINGLE: return ('单倍', 1.0)
    # python-docx 把 1.5/2.0 倍规范化为专用枚举，统一归为"倍数"
    if r in (WD_LINE_SPACING.MULTIPLE, WD_LINE_SPACING.ONE_POINT_FIVE, WD_LINE_SPACING.DOUBLE):
        return ('倍数', round(float(v), 2) if v is not None else None)
    return (str(r), v)

def fmt_ls(pair): return '%s%s' % (pair[0], '' if pair[0] == '单倍' else (('%s磅' if pair[0] == '固定值' else '%s倍') % pair[1]))

def sec_refs(sec, tag):
    return sec._sectPr.findall(qn('w:%sReference' % tag))

def pgnumtype_of(sec):
    el = sec._sectPr.find(qn('w:pgNumType'))
    if el is None: return None, None
    return el.get(qn('w:start')), el.get(qn('w:fmt'))

def hf_text(part):
    return ''.join(p.text for p in part.paragraphs)

def hf_xml(part):
    return ''.join(p._p.xml for p in part.paragraphs)

def num_prefix_re(fmt):
    """'第{n}章'/'{n}.{m}' → 匹配已渲染编号前缀的正则"""
    pat = re.escape(fmt)
    for ph in ('\\{n\\}', '\\{m\\}', '\\{k\\}', '\\{l\\}'):
        pat = pat.replace(ph, r'\d+')
    return re.compile('^' + pat)

# ---------------- 核验 ----------------
class Checker:
    def __init__(self): self.rows = []   # (检查项, 要求, 实际, ok True/False/None=提示)
    def add(self, item, exp, act, ok): self.rows.append((item, str(exp), str(act), ok))
    @property
    def failed(self): return [r for r in self.rows if r[3] is False]

def check_page(doc, spec, body_idx, ck):
    p = spec["page"]; sec = doc.sections[body_idx]
    ew, eh = page_dims(spec)
    aw, ah = sec.page_width.cm, sec.page_height.cm
    ck.add('纸张尺寸', '%.4g×%.4gcm（%s %s）' % (ew, eh, p.get("size", "A4"),
           '横向' if str(p.get("orientation")) == 'landscape' else '纵向'),
           '%.2f×%.2fcm' % (aw, ah), abs(aw - ew) < EPS_CM and abs(ah - eh) < EPS_CM)
    m = p.get("margins_cm", {})
    exp = {k: float(m.get(k, DEFAULT_SPEC["page"]["margins_cm"][k])) for k in ('top', 'bottom', 'left', 'right')}
    act = {'top': sec.top_margin.cm, 'bottom': sec.bottom_margin.cm, 'left': sec.left_margin.cm, 'right': sec.right_margin.cm}
    ok = all(abs(act[k] - exp[k]) < EPS_CM for k in exp)
    ck.add('页边距', '上%(top)s 下%(bottom)s 左%(left)s 右%(right)s cm' % exp,
           '上%.2f 下%.2f 左%.2f 右%.2f cm' % (act['top'], act['bottom'], act['left'], act['right']), ok)
    g = float(p.get("gutter_cm", 0) or 0)
    if g > 0:
        ag = sec.gutter.cm if sec.gutter is not None else 0
        ck.add('装订线', '%scm' % g, '%.2fcm' % ag, abs(ag - g) < EPS_CM)

def check_text_style(style, conf, name, ck, indent_expected=None, check_align_key="align", default_align="left"):
    east, asc = rfonts_of(style.element)
    exp_east = conf["font"]; exp_asc = conf.get("ascii_font") or exp_east
    ck.add('%s·字体' % name, '%s（西文 %s）' % (exp_east, exp_asc), '%s（西文 %s）' % (east, asc),
           east == exp_east and asc == exp_asc)
    exp_pt = pt_of(conf["size"]); act_pt = style.font.size.pt if style.font.size is not None else None
    ck.add('%s·字号' % name, '%s（%.4g磅）' % (conf["size"], exp_pt),
           '%s磅' % act_pt, act_pt is not None and abs(act_pt - exp_pt) < EPS_PT)
    if "bold" in conf:
        ck.add('%s·加粗' % name, conf.get("bold", True), bool(style.font.bold), bool(style.font.bold) == bool(conf.get("bold", True)))
    exp_align = conf.get(check_align_key, default_align)
    act_align = ENUM_ALIGN.get(style.paragraph_format.alignment)
    ck.add('%s·对齐' % name, ALIGN_CN.get(exp_align, exp_align), ALIGN_CN.get(act_align, act_align), act_align == exp_align)
    if indent_expected is not None:
        act_ind = first_line_chars_of(style)
        if indent_expected:
            ck.add('%s·首行缩进' % name, '%s字符' % indent_expected, '%s字符' % act_ind, act_ind == indent_expected)
    if conf.get("line_spacing") is not None or name == '正文':
        exp_ls = ls_expected(conf.get("line_spacing", 1.5))
        act_ls = ls_actual(style.paragraph_format)
        ok = exp_ls[0] == act_ls[0] and act_ls[1] is not None and abs(float(exp_ls[1]) - float(act_ls[1])) < EPS_PT
        ck.add('%s·行距' % name, fmt_ls(exp_ls), fmt_ls(act_ls), ok)

def style_color_val(style):
    """标题样式的 w:color val：None=未设置(继承黑)、'auto'、'000000'、或 Word 默认样式的蓝色(如 0F4761/2E74B5)"""
    rpr = style.element.find(qn('w:rPr'))
    if rpr is None: return None
    c = rpr.find(qn('w:color'))
    return None if c is None else c.get(qn('w:val'))

def check_headings(doc, spec, ck):
    for lvl, key in ((1, 'h1'), (2, 'h2'), (3, 'h3'), (4, 'h4')):
        conf = spec["headings"][key]
        try: st = doc.styles['Heading %d' % lvl]
        except KeyError:
            ck.add('标题%d样式' % lvl, '存在', '缺失', False); continue
        check_text_style(st, conf, '标题%d' % lvl, ck)
        # 标题颜色必须是黑色：出现蓝色标题(0F4761/2E74B5 等)＝没走本包导出脚本(pandoc/Word默认样式特征)
        cv = style_color_val(st)
        col_ok = cv is None or str(cv).lower() in ('auto', '000000')
        ck.add('标题%d·颜色' % lvl, '黑色（标书惯例）',
               '未设置(继承黑色)' if cv is None else cv +
               ('' if col_ok else '（蓝色标题=Word默认样式特征，说明该docx不是 build_tender_docx.py 导出的）'), col_ok)
    # 编号前缀：spec 定了 numbering 的层级，正文里第一个该级标题应带渲染后的编号（或原文自带编号）
    already = re.compile(r'^\s*(第[\d一二三四五六七八九十百]+[章节部分]|[\d一二三四五六七八九十]+[、.．)）]|\d+(\.\d+)*)')
    firsts = {}
    for p in doc.paragraphs:
        n = _sname(p)
        if n.startswith('Heading ') and n not in firsts and p.text.strip(): firsts[n] = p.text.strip()
    for lvl, key in ((1, 'h1'), (2, 'h2'), (3, 'h3'), (4, 'h4')):
        fmt = spec["headings"][key].get("numbering")
        text = firsts.get('Heading %d' % lvl)
        if not fmt or text is None: continue
        ok = bool(num_prefix_re(fmt).match(text) or already.match(text))
        ck.add('标题%d·编号' % lvl, '前缀 "%s"' % fmt, '"%s"' % text[:24], ok)

def check_header_footer(doc, spec, body_idx, restart, title, ck):
    sec = doc.sections[body_idx]
    hd = spec["header"]
    if hd.get("enabled", True):
        text = hf_text(sec.header)
        tpl = str(hd.get("text", "{title}"))
        frags = [f for f in re.split(r'\{title\}', tpl) if f]
        ok = bool(text.strip()) and all(f in text for f in frags)
        if title and '{title}' in tpl: ok = ok and (title[:60] in text or text in tpl.replace('{title}', title)[:60])
        ck.add('页眉', '启用，模板 "%s"' % tpl, '"%s"' % (text or '(空)'), ok)
    else:
        ck.add('页眉', '不启用', '有内容' if hf_text(sec.header).strip() else '(空)', not hf_text(sec.header).strip())
    ft = spec["footer"]
    if ft.get("enabled", True):
        xml = hf_xml(sec.footer); text = hf_text(sec.footer)
        fmt = str(ft.get("format", "第 {page} 页"))
        ok = True; parts = []
        if '{page}' in fmt:
            has = ' PAGE ' in xml; ok &= has; parts.append('页码域%s' % ('✓' if has else '缺失'))
        if '{pages}' in fmt:
            instr = 'SECTIONPAGES' if restart else 'NUMPAGES'
            has = instr in xml; ok &= has; parts.append('总页数域(%s)%s' % (instr, '✓' if has else '缺失'))
        lits = [f for f in re.split(r'\{page\}|\{pages\}', fmt) if f]
        lit_ok = all(l in text for l in lits); ok &= lit_ok
        if lits: parts.append('文字"%s"%s' % ('、'.join(lits), '✓' if lit_ok else '缺失'))
        ck.add('页脚', '格式 "%s"' % fmt, '；'.join(parts) or '(空)', bool(ok))
    else:
        ck.add('页脚', '不启用', '有内容' if hf_text(sec.footer).strip() else '(空)', not hf_text(sec.footer).strip())

def check_page_numbering(doc, spec, restart, ck):
    pn = spec["page_numbering"]
    if not restart:
        ck.add('页码分节', '全文连续（不分节）', '%d 个节' % len(doc.sections), True)
        return 0
    if len(doc.sections) < 2:
        ck.add('页码分节', '封面/目录与正文分节', '仅 %d 个节' % len(doc.sections), False)
        return 0
    body_idx = len(doc.sections) - 1
    start, _ = pgnumtype_of(doc.sections[body_idx])
    exp_start = str(pn.get("start_at", 1))
    ck.add('正文页码起始', '从第 %s 页重新编号' % exp_start, 'w:pgNumType start=%s' % start, start == exp_start)
    front = doc.sections[0]
    if pn.get("front_format") == 'roman':
        _, fmt = pgnumtype_of(front)
        has_pg = any(' PAGE ' in hf_xml(front.footer) for _ in [0]) if sec_refs(front, 'footer') else False
        ck.add('封面/目录页码', '罗马数字页码', 'numFmt=%s，页码域%s' % (fmt, '✓' if has_pg else '无'),
               fmt == 'upperRoman' and has_pg)
    else:
        clean = not sec_refs(front, 'footer') and not sec_refs(front, 'header')
        ck.add('封面/目录页码', '不编页码、无页眉', '前置节无页眉页脚引用' if clean else '前置节带页眉/页脚', clean)
    return body_idx

def check_toc(doc, spec, ck):
    t = spec["toc"]
    xml = doc.element.body.xml
    has = 'TOC \\o' in xml
    if t.get("enabled", True):
        lv = max(1, min(int(t.get("levels", 3)), 9))
        ok = has and ('TOC \\o "1-%d"' % lv) in xml
        title_ok = any(p.text.strip() == str(t.get("title", "目录")).strip() for p in doc.paragraphs[:60])
        ck.add('目录', '自动目录域，%d 级，标题"%s"' % (lv, t.get("title", "目录")),
               '目录域%s，标题%s' % ('✓' if ok else '缺失/级数不符', '✓' if title_ok else '未找到'), ok and title_ok)
    else:
        ck.add('目录', '不启用', '存在目录域' if has else '无', not has)

def check_cover(doc, spec, title, ck):
    c = spec["cover"]
    head = [p.text.strip() for p in doc.paragraphs[:40] if p.text.strip()]
    if c.get("enabled", True):
        sub = str(c.get("subtitle", "")).strip()
        sub_ok = (not sub) or any(sub == t for t in head)
        title_ok = (not title) or any(title == t for t in head)
        ck.add('封面', '含标题%s性质行"%s"' % ('"%s"、' % title if title else '、', sub),
               '标题%s，性质行%s' % ('✓' if title_ok else '未找到', '✓' if sub_ok else '未找到'), sub_ok and title_ok)
        if c.get("fields"):
            miss = [fd.get("label", "") for fd in c["fields"] if not any(str(fd.get("label", "")) in t for t in head)]
            ck.add('封面信息栏', '、'.join(str(fd.get("label", "")) for fd in c["fields"]),
                   '缺 %s' % '、'.join(miss) if miss else '全部齐备', not miss)
    else:
        ck.add('封面', '不启用', '(未核验首段)', None)

def _tbl_first_run(tb):
    for row in tb.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                for r in p.runs:
                    if r.text.strip(): return r
    return None

def _tbl_allowed_pts(ncols, spec_pt):
    """宽表允许的缩字号档位(与 build_tender_docx 的自降规则一致):≥12列→8磅;8~11列→9/8磅;6~7列→五号"""
    if ncols >= 12: allowed = {8.0}
    elif ncols >= 8: allowed = {9.0, 8.0}
    elif ncols >= 6: allowed = {10.5, 9.0}
    else: allowed = {spec_pt}
    allowed.add(min(spec_pt, min(allowed)))   # spec 本身更小时按 spec
    return allowed

def check_tables(doc, spec, ck):
    if not doc.tables:
        ck.add('表格', '（文中无表格）', '无', None); return
    # 列宽门禁:治"每列一个字"竖排病——宽表(≥6列)必须固定布局(autofit 下 Word 会按内容把中文挤成一字一行),
    # 且任何列不得窄于 0.9cm;宽清单应横排或缩字号
    narrow = []
    for ti, tb in enumerate(doc.tables, 1):
        ncols = len(tb.columns)
        lay = tb._tbl.tblPr.find(qn('w:tblLayout'))
        fixed = lay is not None and lay.get(qn('w:type')) == 'fixed'
        grid = tb._tbl.find(qn('w:tblGrid'))
        cols = grid.findall(qn('w:gridCol')) if grid is not None else []
        ws = [int(g.get(qn('w:w')) or 0) / 567.0 for g in cols if g.get(qn('w:w'))]
        if ncols >= 6 and not fixed:
            narrow.append('表%d有%d列却未设固定布局(autofit会把中文列挤成一列一字)' % (ti, ncols))
        elif ws and min(ws) < 0.9:
            narrow.append('表%d最窄列%.2fcm(%d列)' % (ti, min(ws), ncols))
    ck.add('表格·列宽', '宽表(≥6列)固定布局且每列≥0.9cm(防正文竖排成一列一字)',
           '；'.join(narrow) if narrow else '共%d张表,布局与列宽均合规' % len(doc.tables), not narrow)
    ts = spec["table"]; t = doc.tables[0]
    exp_style = ts.get("style", "Table Grid") or "Table Grid"
    act_style = _sname(t) or None
    ck.add('表格·样式', exp_style, act_style, act_style == exp_style)
    exp_font = ts.get("font") or spec["body"]["font"]
    exp_asc = ts.get("ascii_font") or spec["body"].get("ascii_font") or exp_font
    exp_pt = pt_of(ts.get("size", "五号"))
    checked = None; bad = []
    for ti, tb in enumerate(doc.tables, 1):
        run = _tbl_first_run(tb)
        if run is None: continue
        east, asc = rfonts_of(run._element)
        act_pt = run.font.size.pt if run.font.size is not None else None
        allowed = _tbl_allowed_pts(len(tb.columns), exp_pt)
        ok = (east == exp_font and (asc or east) == exp_asc and act_pt is not None
              and any(abs(act_pt - a) < EPS_PT for a in allowed))
        checked = checked or (east, asc, act_pt)
        if not ok: bad.append('表%d:%s %s磅(该表%d列允许%s磅)' % (
            ti, east, act_pt, len(tb.columns), '/'.join('%g' % a for a in sorted(allowed, reverse=True))))
    if checked is None:
        ck.add('表格·字体字号', '%s %s' % (exp_font, ts.get("size", "五号")), '（表格无文字）', None); return
    ck.add('表格·字体字号', '%s（西文 %s）%s(宽表按列数允许缩至小五/8磅)' % (exp_font, exp_asc, ts.get("size", "五号")),
           '；'.join(bad) if bad else '%s（西文 %s）各表字号均在允许档位' % (checked[0], checked[1]), not bad)

def check_images(doc, ck):
    """信息级：统计插入的图片数、残留的原始打标（{{图:..}} 未被解析=缺 tender_images.py）、缺素材占位数"""
    NS = '{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}inline'
    n_img = len(doc.element.body.findall('.//' + NS))
    raw = 0; missing = 0
    for p in doc.paragraphs:
        t = p.text
        raw += len(re.findall(r'\{\{\s*(?:图片?|img|image)\s*[:：]', t)) + len(re.findall(r'〔\s*(?:图片?|img|image)\s*[:：]', t))
        missing += t.count('需人工插入')
    for tbl in doc.tables:
        for row in tbl.rows:
            for cell in row.cells:
                t = cell.text
                raw += len(re.findall(r'\{\{\s*(?:图片?|img|image)\s*[:：]', t))
                missing += t.count('需人工插入')
    if n_img or raw or missing:
        note = '插图 %d 张' % n_img
        if missing: note += '；%d 处缺素材占位(需人工插图)' % missing
        if raw: note += '；%d 处打标未解析(检查 tender_images.py 是否与导出脚本同目录/--images-dir 是否正确)' % raw
        ck.add('图片', '打标图片已插入，缺素材处有占位', note, None if not raw else False)

def check_body_direct_overrides(doc, spec, ck):
    """信息级抽查：正文(Normal)段落里带直接字体/字号覆盖的 run 占比——过高说明没走样式，批量改格式会失控"""
    body_font = spec["body"]["font"]; body_pt = pt_of(spec["body"]["size"])
    started = False; total = 0; overridden = 0
    for p in doc.paragraphs:
        if _sname(p).startswith('Heading '): started = True; continue
        if not started or _sname(p) != 'Normal' or not p.text.strip(): continue
        for r in p.runs:
            if not r.text.strip(): continue
            total += 1
            east, _ = rfonts_of(r._element)
            sz = r.font.size.pt if r.font.size is not None else None
            if (east and east != body_font) or (sz is not None and abs(sz - body_pt) > EPS_PT): overridden += 1
    if total:
        pct = 100.0 * overridden / total
        ck.add('正文直接格式抽查', '正文 run 依赖"正文"样式，直接覆盖越少越好',
               '%d/%d 个 run 带偏离样式的直接格式(%.0f%%)' % (overridden, total, pct),
               None if pct <= 20 else False)

COMMON_BODY_FONTS = {'宋体', '仿宋', '仿宋_GB2312', '楷体', '楷体_GB2312', '黑体',
                     '方正仿宋', '方正仿宋_GBK', '方正仿宋简体', '华文仿宋', '华文中宋'}
H1_OK_FONTS = {'黑体', '宋体', '方正小标宋', '方正小标宋_GBK', '方正小标宋简体', '华文中宋', '方正大标宋'}

def check_conventions(spec, ck, custom_spec):
    """提示级（不改变退出码）：跨平台字体可用性 + 国内标书惯例合理性。
    防两类现场事故：①字体在查看机器缺失→Mac/Windows 观感不一致；②格式提取员臆造 spec 值→
    合法字段+错误值会覆盖国内默认格式,门禁按 spec 核验照样"全过",成品却不像国内标书(GIGO)。"""
    fonts = collect_spec_fonts(spec)
    if fonts:
        ck.add('跨平台·字体可用性', '打开文档的电脑装齐全部所用字体',
               '本文档字体：%s；缺字体的机器上 Word 自动替换、观感不同（Mac 尤甚）——终稿建议同机另存 PDF 一并交付'
               % '、'.join(sorted(fonts)), None)
    legacy = fonts & LEGACY_CN_FONTS
    if legacy:
        ck.add('跨平台·GB2312老字体', '尽量避免（除非招标逐字要求）',
               '%s 在很多电脑缺失；若招标未逐字要求，删 spec 对应字段或改用 仿宋/楷体' % '、'.join(sorted(legacy)), None)
    if not custom_spec: return
    b = spec["body"]
    if str(b.get("font")) not in COMMON_BODY_FONTS:
        ck.add('国内惯例·正文字体', '宋体/仿宋等标书常用字体',
               '%s（spec 指定；与国内标书惯例不符——核对招标原文，若并未如此要求，删掉 spec 的 body.font 用默认宋体）' % b.get("font"), None)
    if str(b.get("align", "justify")) != 'justify':
        ck.add('国内惯例·正文对齐', '两端对齐',
               '%s（与国内标书惯例不符——若招标未要求，删 spec 的 body.align）' % b.get("align"), None)
    h1 = spec["headings"]["h1"]
    if str(h1.get("font")) not in H1_OK_FONTS:
        ck.add('国内惯例·一级标题字体', '黑体/方正小标宋等',
               '%s（与国内标书惯例不符——若招标未要求，删 spec 对应字段）' % h1.get("font"), None)

# ---------------- 报告 ----------------
def write_report(path, docx_path, spec_path, ck):
    n_fail = len(ck.failed); n = len([r for r in ck.rows if r[3] is not None])
    mark = {True: '✅ 符合', False: '❌ 不符', None: '⚠️ 提示'}
    lines = ['# 投标文件格式自检报告', '',
             '- 文件：`%s`' % docx_path,
             '- 依据：%s（未给字段按国内标书默认格式）' % ('`%s`' % spec_path if spec_path else '标准国内标书默认格式'),
             '- 结论：%s' % ('✅ 全部通过（%d 项）' % n if n_fail == 0 else '❌ %d/%d 项不符，需修正后重新导出' % (n_fail, n)), '',
             '| 检查项 | 招标要求 | 实际 | 结果 |', '|---|---|---|---|']
    for item, exp, act, ok in ck.rows:
        lines.append('| %s | %s | %s | %s |' % (item, exp.replace('|', '\\|'), act.replace('|', '\\|'), mark[ok]))
    lines += ['', '> 本报告只覆盖 Word 可承载的格式项；装订/密封/签章/份数等人工事项以《格式要求摘要.md》为准，须人工核对。']
    with open(path, 'w', encoding='utf-8') as f: f.write('\n'.join(lines) + '\n')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('docx'); ap.add_argument('--format-spec', default=None)
    ap.add_argument('--title', default=None, help='项目名称（核验封面/页眉时用，可不传）')
    ap.add_argument('--report', default=None, help='自检报告输出路径，默认写在 docx 旁')
    a = ap.parse_args()
    spec = load_spec(a.format_spec)
    doc = Document(a.docx)
    ck = Checker()

    front = spec["cover"].get("enabled", True) or spec["toc"].get("enabled", True)
    restart = bool(spec["page_numbering"].get("body_restart", True)) and front
    body_idx = check_page_numbering(doc, spec, restart, ck)
    check_page(doc, spec, body_idx, ck)
    check_text_style(doc.styles['Normal'], spec["body"], '正文', ck,
                     indent_expected=spec["body"].get("first_line_indent_chars", 2))
    check_headings(doc, spec, ck)
    check_header_footer(doc, spec, body_idx, restart, a.title, ck)
    check_toc(doc, spec, ck)
    check_cover(doc, spec, a.title, ck)
    check_tables(doc, spec, ck)
    check_images(doc, ck)
    check_body_direct_overrides(doc, spec, ck)
    check_conventions(spec, ck, bool(a.format_spec))

    report = a.report or os.path.join(os.path.dirname(os.path.abspath(a.docx)) or '.',
                                      os.path.splitext(os.path.basename(a.docx))[0] + '_格式自检报告.md')
    write_report(report, a.docx, a.format_spec, ck)
    for item, exp, act, ok in ck.rows:
        print('%s %s：要求 %s ｜ 实际 %s' % ({True: '✅', False: '❌', None: '⚠️'}[ok], item, exp, act))
    if ck.failed:
        print('\n❌ 格式自检未通过：%d 项不符（报告：%s）。修正 word_format_spec.json 或重新导出后再交付。' % (len(ck.failed), report))
        sys.exit(1)
    print('\n✅ 格式自检全部通过（报告：%s）' % report)

if __name__ == '__main__':
    main()
